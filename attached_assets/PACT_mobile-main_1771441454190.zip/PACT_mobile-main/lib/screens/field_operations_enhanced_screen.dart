import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:geolocator/geolocator.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:url_launcher/url_launcher.dart';
import '../widgets/reusable_app_bar.dart';
import '../services/webrtc_service.dart';
import '../services/agora_call_service.dart';
import '../models/call_state.dart';
import 'call_screen.dart';
import 'agora_call_screen.dart';
import '../widgets/custom_drawer_menu.dart';
import '../widgets/notifications_panel.dart';
import '../widgets/main_layout.dart';
import '../widgets/start_visit_dialog.dart';
import '../theme/app_colors.dart';
import '../services/location_service.dart';
import '../services/photo_upload_service.dart';
import '../services/advance_request_service.dart';
import 'package:hive_flutter/hive_flutter.dart';
import '../services/offline/sync_manager.dart';
import '../services/offline/offline_db.dart';
import '../services/offline/models.dart';
import '../models/visit_report.dart';
import '../widgets/request_advance_dialog.dart';
import '../models/site_visit.dart';
import 'visit_report_detail_screen.dart';
import '../widgets/sync_status_indicator.dart';
import '../widgets/complete_visit_flow.dart';
import '../l10n/app_localizations.dart';
import '../services/claim_fee_service.dart';

class FieldOperationsEnhancedScreen extends StatefulWidget {
  const FieldOperationsEnhancedScreen({super.key});

  @override
  State<FieldOperationsEnhancedScreen> createState() => _MMPScreenState();
}

// Alias for backward compatibility
typedef MMPScreen = FieldOperationsEnhancedScreen;

class _MMPScreenState extends State<MMPScreen> {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  bool _isLoading = true;
  bool _isOffline = false;
  bool _isCoordinator = false;
  bool _isDataCollector = false;
  String? _userId;
  String? _userName;
  String? _userStateId;
  String? _userLocalityId;
  String? _userStateName;
  String? _userLocalityName;
  String? _userRole;
  List<String> _userProjectIds = [];
  bool _isAdminOrSuperUser = false;

  // Tab states
  final String _activeTab = 'my-assignments';
  String _enumeratorSubTab = 'claimable';
  String _mySitesSubTab = 'pending';

  // Site entries
  List<Map<String, dynamic>> _availableSites = [];
  List<Map<String, dynamic>> _smartAssignedSites = [];
  List<Map<String, dynamic>> _mySites = [];
  List<Map<String, dynamic>> _unsyncedCompletedVisits = [];
  List<Map<String, dynamic>> _coordinatorSites = [];

  // Advance requests map: siteId -> request data
  Map<String, Map<String, dynamic>> _advanceRequests = {};
  bool _loadingAdvanceRequests = false;

  // User's enumerator fee based on classification
  double _userEnumeratorFee = 50.0; // Default fee if no classification

  // Grouped data
  Map<String, List<Map<String, dynamic>>> _groupedByStateLocality = {};

  // Search
  final TextEditingController _searchController = TextEditingController();
  String _searchQuery = '';

  RealtimeChannel? _realtimeChannel;

  @override
  void initState() {
    super.initState();
    _initializeMMP();
  }

  @override
  void dispose() {
    _realtimeChannel?.unsubscribe();
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _initializeMMP() async {
    try {
      var user = Supabase.instance.client.auth.currentUser;
      // Cold start: auth may not have restored yet. Wait briefly then try stored userId.
      if (user == null) {
        await Future.delayed(const Duration(milliseconds: 600));
        user = Supabase.instance.client.auth.currentUser;
      }
      if (user == null) {
        final lastUserId = await _getStoredUserId();
        if (lastUserId != null) {
          debugPrint(
            '[_initializeMMP] No auth yet - loading from cache/site_visits for stored user',
          );
          await _initializeFromCache(lastUserId);
          if (!mounted) return;
          setState(() => _isLoading = false);
          return;
        }
        if (!mounted) return;
        setState(() => _isLoading = false);
        return;
      }

      _userId = user.id;
      await _storeUserId(user.id);

      // Check connectivity first
      final connectivityResult = await Connectivity().checkConnectivity();
      final isOffline = connectivityResult.contains(ConnectivityResult.none);

      if (mounted) {
        setState(() => _isOffline = isOffline);
      }

      if (isOffline) {
        // OFFLINE MODE: Load everything from cache
        debugPrint('[_initializeMMP] Offline - loading from cache');
        await _initializeFromCache(user.id);
        return;
      }

      // ONLINE MODE: Fetch from Supabase and cache
      try {
        // Get user profile to determine role
        final profileResponse = await Supabase.instance.client
            .from('profiles')
            .select('role, state_id, locality_id')
            .eq('id', user.id)
            .maybeSingle();

        if (profileResponse != null) {
          // Cache profile for offline use
          final offlineDb = OfflineDb();
          await offlineDb.cacheItem(
            OfflineDb.profileCacheBox,
            'profile_${user.id}',
            data: profileResponse,
            ttl: const Duration(days: 7),
          );

          _applyProfileData(profileResponse);

          // Fetch user's project memberships (for non-admin users)
          if (!_isAdminOrSuperUser) {
            await _fetchUserProjectMemberships();
          }

          // Query actual state and locality names from database
          await _loadLocationNames();
        } else {
          // Profile fetch returned null (e.g. flaky connection, lost internet).
          // Try cache so user can continue in offline mode instead of Access Denied.
          debugPrint('[_initializeMMP] Profile null, falling back to cache');
          await _initializeFromCache(user.id);
          return;
        }

        // Load data based on role
        // Coordinators should see the same MMP experience as data collectors
        if (_isDataCollector || _isCoordinator) {
          await _loadDataCollectorData();
          _setupRealtimeSubscription();
        }

        if (!mounted) return;
        setState(() => _isLoading = false);
      } catch (e) {
        // Network error while online - fall back to cache
        debugPrint('[_initializeMMP] Network error, falling back to cache: $e');
        await _initializeFromCache(user.id);
      }
    } catch (e) {
      debugPrint('Error initializing MMP: $e');
      // Last resort - try cache
      final user = Supabase.instance.client.auth.currentUser;
      if (user != null) {
        await _initializeFromCache(user.id);
      } else {
        final lastUserId = await _getStoredUserId();
        if (lastUserId != null) {
          await _initializeFromCache(lastUserId);
        }
        if (!mounted) return;
        setState(() => _isLoading = false);
      }
    }
  }

  static const String _lastUserIdKey = 'last_user_id';

  Future<void> _storeUserId(String userId) async {
    try {
      final box = await Hive.openBox('user_profile_cache');
      await box.put(_lastUserIdKey, userId);
    } catch (e) {
      debugPrint('[_storeUserId] Error: $e');
    }
  }

  Future<String?> _getStoredUserId() async {
    try {
      final box = await Hive.openBox('user_profile_cache');
      return box.get(_lastUserIdKey) as String?;
    } catch (e) {
      debugPrint('[_getStoredUserId] Error: $e');
      return null;
    }
  }

  /// Initialize from cached data when offline
  Future<void> _initializeFromCache(String userId) async {
    try {
      // CRITICAL: Set _userId BEFORE loading from cache (cache keys use _userId)
      _userId = userId;

      if (mounted) {
        setState(() => _isOffline = true);
      }
      debugPrint(
        '[_initializeFromCache] Loading cached profile and data for user: $_userId',
      );
      final offlineDb = OfflineDb();

      // Load cached profile
      final cachedItem = offlineDb.getCachedItem(
        OfflineDb.profileCacheBox,
        'profile_$userId',
      );

      Map<String, dynamic>? cachedProfile;
      if (cachedItem?.data != null) {
        try {
          cachedProfile = Map<String, dynamic>.from(cachedItem!.data);
        } catch (e) {
          debugPrint('[_initializeFromCache] Error converting cached profile: $e');
        }
      }

      if (cachedProfile != null) {
        _applyProfileData(cachedProfile);
        debugPrint('[_initializeFromCache] Loaded cached profile: $_userRole');
      } else {
        debugPrint('[_initializeFromCache] No cached profile found, trying fallback methods');

        // FALLBACK 1: Try to load role from Hive cache
        try {
          final box = await Hive.openBox('user_profile_cache');
          final cachedRole = box.get('user_role') as String?;
          if (cachedRole != null) {
            debugPrint('[_initializeFromCache] Found role in Hive cache: $cachedRole');
            final role = cachedRole.toLowerCase();
            _userRole = role;
            _isCoordinator =
                role == 'coordinator' ||
                role == 'field_coordinator' ||
                role == 'state_coordinator';
            _isDataCollector =
                role == 'datacollector' ||
                role == 'enumerator' ||
                role == 'data_collector';
            _isAdminOrSuperUser =
                role == 'admin' ||
                role == 'super_admin' ||
                role == 'supervisor' ||
                role == 'fom';
          }
        } catch (e) {
          debugPrint('[_initializeFromCache] Error loading role from Hive cache: $e');
        }

        // FALLBACK 2: Try to get role from user metadata (if available)
        if (!_isDataCollector && !_isCoordinator) {
          try {
            final user = Supabase.instance.client.auth.currentUser;
            if (user != null) {
              final metadataRole = user.userMetadata?['role'] as String?;
              if (metadataRole != null) {
                final role = metadataRole.toLowerCase();
                _userRole = role;
                _isCoordinator =
                    role == 'coordinator' ||
                    role == 'field_coordinator' ||
                    role == 'state_coordinator';
                _isDataCollector =
                    role == 'datacollector' ||
                    role == 'enumerator' ||
                    role == 'data_collector';
                _isAdminOrSuperUser =
                    role == 'admin' ||
                    role == 'super_admin' ||
                    role == 'supervisor' ||
                    role == 'fom';
              }
            }
          } catch (e) {
            debugPrint('[_initializeFromCache] Error loading role from metadata: $e');
          }
        }
      }

      // Load data based on role - mirror the online path
      if (_isDataCollector || _isCoordinator) {
        await _loadDataCollectorData();
        // Group sites after loading
        _groupAvailableSites();
        // Load advance requests from cache if available
        await _loadAdvanceRequests();
      }

      // Coordinators also need coordinator data
      if (_isCoordinator) {
        await _loadCoordinatorData();
      }

      if (!mounted) return;
      setState(() => _isLoading = false);
    } catch (e) {
      debugPrint('[_initializeFromCache] Error: $e');
      if (!mounted) return;
      setState(() => _isLoading = false);
    }
  }

  /// Apply profile data to instance variables
  void _applyProfileData(Map<String, dynamic> profileResponse) {
    _userRole = (profileResponse['role'] as String?)?.toLowerCase() ?? '';
    _userName =
        profileResponse['full_name'] as String? ??
        profileResponse['name'] as String? ??
        profileResponse['email'] as String? ??
        'PACT User';
    _isCoordinator =
        _userRole == 'coordinator' ||
        _userRole == 'field_coordinator' ||
        _userRole == 'state_coordinator';
    _isDataCollector =
        _userRole == 'datacollector' ||
        _userRole == 'enumerator' ||
        _userRole == 'data_collector';

    _userStateId = profileResponse['state_id'] as String?;
    _userLocalityId = profileResponse['locality_id'] as String?;

    // Check if user is admin or supervisor (can see all projects)
    _isAdminOrSuperUser =
        _userRole == 'admin' ||
        _userRole == 'super_admin' ||
        _userRole == 'supervisor' ||
        _userRole == 'fom';
  }

  void _setupRealtimeSubscription() {
    try {
      _realtimeChannel?.unsubscribe();

      _realtimeChannel = Supabase.instance.client
          .channel('mmp_realtime')
          .onPostgresChanges(
            event: PostgresChangeEvent.all,
            schema: 'public',
            table: 'mmp_site_entries',
            callback: (payload) {
              debugPrint('mmp_site_entries changed, reloading...');
              if (_isDataCollector || _isCoordinator) {
                _loadDataCollectorData();
              }
            },
          )
          .onPostgresChanges(
            event: PostgresChangeEvent.all,
            schema: 'public',
            table: 'down_payment_requests',
            callback: (payload) async {
              debugPrint('down_payment_requests changed, reloading...');
              if (!_isDataCollector && !_isCoordinator) return;
              if (!mounted) return;
              await _loadAdvanceRequests();
              if (!mounted) return;
              setState(() {});
            },
          )
          .subscribe();
    } catch (e) {
      debugPrint('Error setting up real-time subscription: $e');
    }
  }

  /// Fetch user's enumerator fee based on classification
  Future<void> _loadUserEnumeratorFee() async {
    if (_userId == null) return;

    final supabase = Supabase.instance.client;

    try {
      // Get user's classification
      final classificationResult = await supabase
          .from('user_classifications')
          .select('classification_level, role_scope, is_active')
          .eq('user_id', _userId!)
          .eq('is_active', true)
          .order('effective_from', ascending: false)
          .limit(1)
          .maybeSingle();

      if (classificationResult == null) {
        debugPrint(
          '[_loadUserEnumeratorFee] No classification found, using default fee',
        );
        return;
      }

      final classificationLevel = classificationResult['classification_level'];
      final roleScope = classificationResult['role_scope'];
      debugPrint(
        '[_loadUserEnumeratorFee] user_classifications from DB: '
        'classification_level=$classificationLevel, role_scope=$roleScope (raw)',
      );

      // Get fee structure for this classification
      final feeResult = await supabase
          .from('classification_fee_structures')
          .select('site_visit_base_fee_cents, complexity_multiplier, is_active')
          .eq('classification_level', classificationLevel)
          .eq('role_scope', roleScope)
          .eq('is_active', true)
          .order('effective_from', ascending: false)
          .limit(1)
          .maybeSingle();

      if (feeResult != null) {
        final baseFee =
            (feeResult['site_visit_base_fee_cents'] as num?)?.toDouble() ?? 0;
        final multiplier =
            (feeResult['complexity_multiplier'] as num?)?.toDouble() ?? 1.0;
        _userEnumeratorFee = (baseFee * multiplier * 100).roundToDouble() / 100;
        debugPrint(
          '[_loadUserEnumeratorFee] Calculated fee: $_userEnumeratorFee SDG (level: $classificationLevel)',
        );
      } else {
        debugPrint(
          '[_loadUserEnumeratorFee] No fee structure found, using default',
        );
      }
    } catch (e) {
      debugPrint('[_loadUserEnumeratorFee] Error: $e');
    }
  }

  Future<void> _loadDataCollectorData({
    bool preserveExistingData = false,
  }) async {
    final supabase = Supabase.instance.client;

    try {
      // Check connectivity first - if offline, load from cache directly
      final connectivityResult = await Connectivity().checkConnectivity();
      final isOffline = connectivityResult.contains(ConnectivityResult.none);

      if (isOffline) {
        debugPrint(
          '[_loadDataCollectorData] Offline - loading all data from cache',
        );
        await _loadAvailableSitesFromCache();
        await _loadSmartAssignedSitesFromCache();
        await _loadMySitesFromCache();
        if (_mySites.isEmpty) await _loadMySitesFromSiteVisitsBox();
        await _loadUnsyncedCompletedVisits();
        _groupAvailableSites();
        debugPrint('[_loadDataCollectorData] Offline load completed');
        return;
      }

      // Validate session before starting reload (only when online)
      var session = supabase.auth.currentSession;
      if (session == null || session.isExpired) {
        debugPrint('[_loadDataCollectorData] Session expired, refreshing...');
        try {
          await supabase.auth.refreshSession();
          session = supabase.auth.currentSession;
          if (session == null) {
            debugPrint(
              '[_loadDataCollectorData] Session refresh failed - loading from cache',
            );
            await _loadAvailableSitesFromCache();
            await _loadSmartAssignedSitesFromCache();
            await _loadMySitesFromCache();
            if (_mySites.isEmpty) await _loadMySitesFromSiteVisitsBox();
            await _loadUnsyncedCompletedVisits();
            _groupAvailableSites();
            return;
          }
          // Update _userId if it changed
          final currentUserId = supabase.auth.currentUser?.id;
          if (currentUserId != null) {
            _userId = currentUserId;
          }
        } catch (refreshError) {
          debugPrint(
            '[_loadDataCollectorData] Session refresh error: $refreshError - loading from cache',
          );
          await _loadAvailableSitesFromCache();
          await _loadSmartAssignedSitesFromCache();
          await _loadMySitesFromCache();
          if (_mySites.isEmpty) await _loadMySitesFromSiteVisitsBox();
          await _loadUnsyncedCompletedVisits();
          _groupAvailableSites();
          return;
        }
      }

      // Re-validate _userId from current session
      final currentUserId = supabase.auth.currentUser?.id;
      if (currentUserId == null) {
        debugPrint(
          '[_loadDataCollectorData] User ID is null - loading from cache',
        );
        await _loadAvailableSitesFromCache();
        await _loadSmartAssignedSitesFromCache();
        await _loadMySitesFromCache();
        if (_mySites.isEmpty) await _loadMySitesFromSiteVisitsBox();
        await _loadUnsyncedCompletedVisits();
        _groupAvailableSites();
        return;
      }
      _userId = currentUserId;

      debugPrint(
        '[_loadDataCollectorData] Starting reload with userId: $_userId (preserveExistingData: $preserveExistingData)',
      );

      // If preserving data, don't clear existing lists - they'll be updated with new data
      if (!preserveExistingData) {
        // Only clear if this is a fresh load, not a background refresh
      }

      // Load user's enumerator fee based on classification
      await _loadUserEnumeratorFee();

      // Load available sites (Dispatched, not accepted, in collector's area)
      await _loadAvailableSites();

      // Verify session after each major operation
      session = supabase.auth.currentSession;
      if (session == null || session.isExpired) {
        debugPrint(
          '[_loadDataCollectorData] Session expired after _loadAvailableSites, refreshing...',
        );
        await supabase.auth.refreshSession();
      }

      // Load smart assigned sites (status = 'Assigned', accepted_by = currentUser, not cost-acknowledged)
      await _loadSmartAssignedSites();

      // Verify session
      session = supabase.auth.currentSession;
      if (session == null || session.isExpired) {
        debugPrint(
          '[_loadDataCollectorData] Session expired after _loadSmartAssignedSites, refreshing...',
        );
        await supabase.auth.refreshSession();
      }

      // Load my sites (all sites accepted by this collector)
      await _loadMySites();

      // Verify session
      session = supabase.auth.currentSession;
      if (session == null || session.isExpired) {
        debugPrint(
          '[_loadDataCollectorData] Session expired after _loadMySites, refreshing...',
        );
        await supabase.auth.refreshSession();
      }

      // Load unsynced completed visits (from offline DB if available)
      await _loadUnsyncedCompletedVisits();

      // Load advance requests
      await _loadAdvanceRequests();

      // Group available sites by state-locality
      _groupAvailableSites();

      debugPrint('[_loadDataCollectorData] Reload completed successfully');

      // When online and we have pending offline completions, trigger sync so they upload
      try {
        final offlineDb = OfflineDb();
        final unsyncedVisits = offlineDb.getUnsyncedSiteVisits();
        if (unsyncedVisits.isNotEmpty) {
          debugPrint(
            '[_loadDataCollectorData] Found ${unsyncedVisits.length} unsynced site visit(s), triggering sync',
          );
          final syncManager = SyncManager();
          syncManager.setSupabaseClient(Supabase.instance.client);
          syncManager.forceSync();
        }
      } catch (syncTriggerError) {
        debugPrint(
          '[_loadDataCollectorData] Failed to trigger sync: $syncTriggerError',
        );
      }
    } catch (e) {
      debugPrint(
        '[_loadDataCollectorData] Error loading data collector data: $e',
      );

      // Check if it's an auth error
      final errorStr = e.toString().toLowerCase();
      if (errorStr.contains('auth') ||
          errorStr.contains('unauthorized') ||
          errorStr.contains('jwt') ||
          errorStr.contains('token')) {
        debugPrint(
          '[_loadDataCollectorData] Auth error during reload - attempting recovery',
        );
        try {
          await supabase.auth.refreshSession();
          debugPrint(
            '[_loadDataCollectorData] Session refreshed after auth error',
          );
        } catch (refreshError) {
          debugPrint(
            '[_loadDataCollectorData] Session refresh after error failed: $refreshError',
          );
          // Don't throw - just log and return, don't trigger logout
        }
      }

      // Fall back to Hive/OfflineDb when any load error occurs (e.g. network
      // failure after cold start). Ensures sites show in tabs (Drafts, Completed,
      // etc.) when app thinks it's online but requests fail.
      debugPrint(
        '[_loadDataCollectorData] Falling back to offline storage (Hive)',
      );
      try {
        await _loadAvailableSitesFromCache();
        await _loadSmartAssignedSitesFromCache();
        await _loadMySitesFromCache();
        if (_mySites.isEmpty) await _loadMySitesFromSiteVisitsBox();
        await _loadUnsyncedCompletedVisits();
        _groupAvailableSites();
        if (mounted) {
          setState(() => _isOffline = true);
        }
        debugPrint(
          '[_loadDataCollectorData] Offline fallback completed successfully',
        );
      } catch (fallbackError) {
        debugPrint(
          '[_loadDataCollectorData] Offline fallback failed: $fallbackError',
        );
      }
      // Don't rethrow - we don't want reload errors to cause logout
    }
  }

  /// Fetch user's project memberships from team_members table and projects table
  Future<void> _fetchUserProjectMemberships() async {
    try {
      _userProjectIds = [];

      debugPrint(
        '[_fetchUserProjectMemberships] Fetching projects for user: $_userId',
      );

      // Try to fetch from team_members table first (if it exists)
      try {
        final response = await Supabase.instance.client
            .from('team_members')
            .select('project_id')
            .eq('user_id', _userId!);

        if ((response as List).isNotEmpty) {
          _userProjectIds = (response as List)
              .map((m) => m['project_id']?.toString())
              .where((id) => id != null && id.isNotEmpty)
              .cast<String>()
              .toList();
          debugPrint(
            'User project IDs from team_members: ${_userProjectIds.length}',
          );
        } else {
          debugPrint(
            'team_members table returned empty or doesn\'t exist, checking projects table',
          );
        }
      } catch (e) {
        debugPrint(
          'Error fetching from team_members table (may not exist): $e',
        );
      }

      // ALWAYS check projects table for team composition (primary source)
      // This matches the web app's useUserProjects hook
      try {
        final projectsResponse = await Supabase.instance.client
            .from('projects')
            .select('id, team');

        debugPrint(
          'Checking ${(projectsResponse as List).length} projects for user membership',
        );
        int foundCount = 0;

        for (final project in projectsResponse as List) {
          final projectId = project['id']?.toString();
          if (projectId == null) continue;

          final team = project['team'] as Map<String, dynamic>?;
          if (team == null) continue;

          bool isMember = false;

          // Check if user is project manager (can be UUID or name)
          final projectManager = team['projectManager'];
          if (projectManager != null) {
            // Check both UUID and name (in case it's stored as name)
            if (projectManager == _userId ||
                (projectManager is String &&
                    projectManager.contains(_userId!))) {
              isMember = true;
              debugPrint(
                'Found user as project manager in project: $projectId',
              );
            }
          }

          // Check if user is in members array
          if (!isMember) {
            final members = team['members'] as List?;
            if (members != null && members.contains(_userId)) {
              isMember = true;
              debugPrint('Found user in members array for project: $projectId');
            }
          }

          // Check if user is in teamComposition (primary method)
          if (!isMember) {
            final teamComposition = team['teamComposition'] as List?;
            if (teamComposition != null) {
              for (final member in teamComposition) {
                if (member is Map) {
                  final memberUserId = member['userId']?.toString();
                  if (memberUserId == _userId) {
                    isMember = true;
                    debugPrint(
                      'Found user in teamComposition for project: $projectId (role: ${member['role']})',
                    );
                    break;
                  }
                }
              }
            }
          }

          if (isMember && !_userProjectIds.contains(projectId)) {
            _userProjectIds.add(projectId);
            foundCount++;
          }
        }

        debugPrint(
          'User project IDs from projects table: $foundCount (total: ${_userProjectIds.length})',
        );
      } catch (e2) {
        debugPrint('Error fetching from projects table: $e2');
      }

      debugPrint(
        'User is member of ${_userProjectIds.length} projects: $_userProjectIds',
      );
    } catch (e) {
      debugPrint('Error fetching user project memberships: $e');
    }
  }

  Future<void> _loadLocationNames() async {
    try {
      // Load state name from hub_states table
      if (_userStateId != null) {
        final hubState = await Supabase.instance.client
            .from('hub_states')
            .select('state_name')
            .eq('state_id', _userStateId!)
            .maybeSingle();

        if (hubState != null) {
          _userStateName = hubState['state_name'] as String?;
        } else {
          // Fallback: Try sites_registry if hub_states doesn't have it
          final registryState = await Supabase.instance.client
              .from('sites_registry')
              .select('state_name')
              .eq('state_id', _userStateId!)
              .limit(1)
              .maybeSingle();

          _userStateName = registryState?['state_name'] as String?;
        }

        debugPrint(
          'Loaded state name: $_userStateName for state_id: $_userStateId',
        );
      }

      // Load locality name from sites_registry table
      if (_userLocalityId != null && _userStateId != null) {
        final locality = await Supabase.instance.client
            .from('sites_registry')
            .select('locality_name')
            .eq('locality_id', _userLocalityId!)
            .eq('state_id', _userStateId!)
            .limit(1)
            .maybeSingle();

        _userLocalityName = locality?['locality_name'] as String?;
        debugPrint(
          'Loaded locality name: $_userLocalityName for locality_id: $_userLocalityId',
        );
      }
    } catch (e) {
      debugPrint('Error loading location names: $e');
      // If lookup fails, we'll show all dispatched sites (fallback behavior)
    }
  }

  Future<void> _loadAvailableSites() async {
    final supabase = Supabase.instance.client;

    try {
      if (_userId == null) return;

      // Check connectivity first
      final connectivityResult = await Connectivity().checkConnectivity();
      final isOffline = connectivityResult.contains(ConnectivityResult.none);

      if (isOffline) {
        debugPrint('[_loadAvailableSites] Offline - loading from cache');
        await _loadAvailableSitesFromCache();
        return;
      }

      // Verify session before query
      var session = supabase.auth.currentSession;
      if (session == null || session.isExpired) {
        debugPrint('[_loadAvailableSites] Session expired, refreshing...');
        await supabase.auth.refreshSession();
      }

      debugPrint('Loading available sites...');
      debugPrint('User state: $_userStateName (ID: $_userStateId)');
      debugPrint('User locality: $_userLocalityName (ID: $_userLocalityId)');

      // Build query step by step
      var query = supabase
          .from('mmp_site_entries')
          .select('*, mmp_files(project_id)')
          .ilike('status', 'Dispatched');

      // Filter by state - must match web behavior exactly
      // Web app: Users MUST have a state_id assigned to see claimable sites
      // If user has no state assigned, return empty list (no sites to claim)
      if (_userStateName == null || _userStateName!.isEmpty) {
        debugPrint(
          '[_loadAvailableSites] No state assigned to user - returning empty list (matching web behavior)',
        );
        debugPrint(
          '[_loadAvailableSites] User stateId: $_userStateId, stateName: $_userStateName',
        );
        _availableSites = [];
        return;
      }

      // Filter by state (all sites in user's state are claimable, not just locality)
      // This matches web behavior: users can claim any site in their assigned state
      debugPrint('Filtering by state: $_userStateName');
      query = query.ilike('state', '%$_userStateName%');

      final response = await query
          .order('created_at', ascending: false)
          .limit(1000);

      // Filter out sites that have been accepted (accepted_by is not null)
      List<Map<String, dynamic>> filteredSites = (response as List)
          .map((e) => e as Map<String, dynamic>)
          .where((site) => site['accepted_by'] == null)
          .toList();

      // Filter by project membership (for non-admin users)
      if (!_isAdminOrSuperUser) {
        final beforeCount = filteredSites.length;
        filteredSites = filteredSites.where((site) {
          final mmpFile = site['mmp_files'] as Map<String, dynamic>? ?? {};
          final projectId = mmpFile['project_id']?.toString();

          // If site has no project ID, exclude it
          if (projectId == null || projectId.isEmpty) {
            return false;
          }

          // Site must be in one of user's projects
          return _userProjectIds.contains(projectId);
        }).toList();

        debugPrint(
          'Filtered available sites by project: ${filteredSites.length} of $beforeCount',
        );
      }

      _availableSites = filteredSites;

      debugPrint('Loaded ${_availableSites.length} available sites');

      // Cache the sites for offline use
      await _cacheAvailableSites(filteredSites);

      // Debug: Print first few sites for verification
      if (_availableSites.isNotEmpty) {
        debugPrint(
          'Sample site: ${_availableSites.first['site_name']} - State: ${_availableSites.first['state']} - Locality: ${_availableSites.first['locality']}',
        );
      }
    } catch (e) {
      debugPrint('[_loadAvailableSites] Error loading available sites: $e');

      // Check if it's a network error - fall back to cache
      final errorStr = e.toString().toLowerCase();
      if (e is SocketException ||
          errorStr.contains('socketexception') ||
          errorStr.contains('failed host lookup') ||
          errorStr.contains('connection refused') ||
          errorStr.contains('network is unreachable') ||
          errorStr.contains('no address associated') ||
          errorStr.contains('connection timed out') ||
          errorStr.contains('errno = 7')) {
        debugPrint(
          '[_loadAvailableSites] Network error - falling back to cache',
        );
        await _loadAvailableSitesFromCache();
        return;
      }

      // Check if it's an auth error
      if (errorStr.contains('auth') ||
          errorStr.contains('unauthorized') ||
          errorStr.contains('jwt') ||
          errorStr.contains('token')) {
        debugPrint(
          '[_loadAvailableSites] Auth error - attempting session refresh',
        );
        try {
          await supabase.auth.refreshSession();
          // Don't retry automatically - just log and set empty list
        } catch (refreshError) {
          debugPrint(
            '[_loadAvailableSites] Session refresh failed: $refreshError',
          );
        }
      }

      // Try to load from cache as last resort
      if (_availableSites.isEmpty) {
        await _loadAvailableSitesFromCache();
      }
    }
  }

  Future<void> _cacheAvailableSites(List<Map<String, dynamic>> sites) async {
    try {
      final offlineDb = OfflineDb();
      await offlineDb.cacheItem(
        OfflineDb.siteCacheBox,
        'available_sites_$_userId',
        data: {'sites': sites},
        ttl: const Duration(hours: 24),
      );
      debugPrint(
        '[_cacheAvailableSites] Cached ${sites.length} available sites',
      );
    } catch (e) {
      debugPrint('[_cacheAvailableSites] Error caching sites: $e');
    }
  }

  Future<void> _loadAvailableSitesFromCache() async {
    try {
      final offlineDb = OfflineDb();
      final cachedItem = offlineDb.getCachedItem(
        OfflineDb.siteCacheBox,
        'available_sites_$_userId',
      );

      if (cachedItem != null && cachedItem.data != null) {
        final data = cachedItem.data;
        final sites = data['sites'] as List?;
        if (sites != null) {
          _availableSites = sites.map((e) {
            try {
              return Map<String, dynamic>.from(e as Map);
            } catch (_) {
              return <String, dynamic>{};
            }
          }).where((e) => e.isNotEmpty).toList();
          debugPrint(
            '[_loadAvailableSitesFromCache] Loaded ${_availableSites.length} sites from cache',
          );
        } else {
          _availableSites = [];
        }
      } else {
        debugPrint('[_loadAvailableSitesFromCache] No cached sites found');
        _availableSites = [];
      }
    } catch (e) {
      debugPrint('[_loadAvailableSitesFromCache] Error loading from cache: $e');
      _availableSites = [];
    }
  }

  Future<void> _loadSmartAssignedSites() async {
    final supabase = Supabase.instance.client;

    try {
      if (_userId == null) return;

      // Check connectivity first
      final connectivityResult = await Connectivity().checkConnectivity();
      final isOffline = connectivityResult.contains(ConnectivityResult.none);

      if (isOffline) {
        debugPrint('[_loadSmartAssignedSites] Offline - loading from cache');
        await _loadSmartAssignedSitesFromCache();
        return;
      }

      // Verify session before query
      var session = supabase.auth.currentSession;
      if (session == null || session.isExpired) {
        debugPrint('[_loadSmartAssignedSites] Session expired, refreshing...');
        await supabase.auth.refreshSession();
      }

      final response = await supabase
          .from('mmp_site_entries')
          .select('*, mmp_files(project_id)')
          .ilike('status', 'Assigned')
          .eq('accepted_by', _userId!)
          .order('created_at', ascending: false)
          .limit(1000);

      final allSites = (response as List)
          .map((e) => e as Map<String, dynamic>)
          .toList();

      // Filter out cost-acknowledged sites
      List<Map<String, dynamic>> costFilteredSites = allSites.where((site) {
        final additionalData = _safeParseAdditionalData(
          site['additional_data'],
        );
        final costAcknowledged =
            site['cost_acknowledged'] ??
            additionalData['cost_acknowledged'] ??
            false;
        return !costAcknowledged;
      }).toList();

      // Filter by project membership (for non-admin users)
      if (!_isAdminOrSuperUser) {
        final beforeCount = costFilteredSites.length;
        costFilteredSites = costFilteredSites.where((site) {
          final mmpFile = site['mmp_files'] as Map<String, dynamic>? ?? {};
          final projectId = mmpFile['project_id']?.toString();

          // If site has no project ID, exclude it
          if (projectId == null || projectId.isEmpty) {
            return false;
          }

          // Site must be in one of user's projects
          return _userProjectIds.contains(projectId);
        }).toList();

        debugPrint(
          'Filtered smart assigned sites by project: ${costFilteredSites.length} of $beforeCount',
        );
      }

      _smartAssignedSites = costFilteredSites;

      // Cache for offline use
      await _cacheSmartAssignedSites(costFilteredSites);
    } catch (e) {
      debugPrint(
        '[_loadSmartAssignedSites] Error loading smart assigned sites: $e',
      );

      // Check if it's a network error - fall back to cache
      final errorStr = e.toString().toLowerCase();
      if (e is SocketException ||
          errorStr.contains('socketexception') ||
          errorStr.contains('failed host lookup') ||
          errorStr.contains('connection refused') ||
          errorStr.contains('network is unreachable') ||
          errorStr.contains('no address associated') ||
          errorStr.contains('connection timed out') ||
          errorStr.contains('errno = 7')) {
        debugPrint(
          '[_loadSmartAssignedSites] Network error - falling back to cache',
        );
        await _loadSmartAssignedSitesFromCache();
        return;
      }

      // Check if it's an auth error
      if (errorStr.contains('auth') ||
          errorStr.contains('unauthorized') ||
          errorStr.contains('jwt') ||
          errorStr.contains('token')) {
        debugPrint(
          '[_loadSmartAssignedSites] Auth error - attempting session refresh',
        );
        try {
          await supabase.auth.refreshSession();
        } catch (refreshError) {
          debugPrint(
            '[_loadSmartAssignedSites] Session refresh failed: $refreshError',
          );
        }
      }

      // Try cache as fallback
      if (_smartAssignedSites.isEmpty) {
        await _loadSmartAssignedSitesFromCache();
      }
    }
  }

  Future<void> _cacheSmartAssignedSites(
    List<Map<String, dynamic>> sites,
  ) async {
    try {
      final offlineDb = OfflineDb();
      await offlineDb.cacheItem(
        OfflineDb.siteCacheBox,
        'smart_assigned_sites_$_userId',
        data: {'sites': sites},
        ttl: const Duration(hours: 24),
      );
      debugPrint(
        '[_cacheSmartAssignedSites] Cached ${sites.length} assigned sites',
      );
    } catch (e) {
      debugPrint('[_cacheSmartAssignedSites] Error caching sites: $e');
    }
  }

  Future<void> _loadSmartAssignedSitesFromCache() async {
    try {
      final offlineDb = OfflineDb();
      final cachedItem = offlineDb.getCachedItem(
        OfflineDb.siteCacheBox,
        'smart_assigned_sites_$_userId',
      );

      if (cachedItem != null && cachedItem.data != null) {
        final data = cachedItem.data;
        final sites = data['sites'] as List?;
        if (sites != null) {
          _smartAssignedSites = sites.map((e) {
            try {
              return Map<String, dynamic>.from(e as Map);
            } catch (_) {
              return <String, dynamic>{};
            }
          }).where((e) => e.isNotEmpty).toList();
          debugPrint(
            '[_loadSmartAssignedSitesFromCache] Loaded ${_smartAssignedSites.length} sites from cache',
          );
        } else {
          _smartAssignedSites = [];
        }
      } else {
        debugPrint('[_loadSmartAssignedSitesFromCache] No cached sites found');
        _smartAssignedSites = [];
      }
    } catch (e) {
      debugPrint(
        '[_loadSmartAssignedSitesFromCache] Error loading from cache: $e',
      );
      _smartAssignedSites = [];
    }
  }

  Future<void> _loadMySites() async {
    final supabase = Supabase.instance.client;

    try {
      if (_userId == null) return;

      // Check connectivity first
      final connectivityResult = await Connectivity().checkConnectivity();
      final isOffline = connectivityResult.contains(ConnectivityResult.none);

      if (isOffline) {
        debugPrint('[_loadMySites] Offline - loading from cache');
        await _loadMySitesFromCache();
        return;
      }

      // Verify session before query
      var session = supabase.auth.currentSession;
      if (session == null || session.isExpired) {
        debugPrint('[_loadMySites] Session expired, refreshing...');
        await supabase.auth.refreshSession();
      }

      final response = await supabase
          .from('mmp_site_entries')
          .select('*, mmp_files(project_id)')
          .eq('accepted_by', _userId!)
          .order('created_at', ascending: false)
          .limit(1000);

      List<Map<String, dynamic>> allSites = (response as List)
          .map((e) => e as Map<String, dynamic>)
          .toList();

      // Filter by project membership (for non-admin users)
      if (!_isAdminOrSuperUser) {
        final beforeCount = allSites.length;
        allSites = allSites.where((site) {
          final mmpFile = site['mmp_files'] as Map<String, dynamic>? ?? {};
          final projectId = mmpFile['project_id']?.toString();

          // If site has no project ID, exclude it
          if (projectId == null || projectId.isEmpty) {
            return false;
          }

          // Site must be in one of user's projects
          return _userProjectIds.contains(projectId);
        }).toList();

        debugPrint(
          'Filtered my sites by project: ${allSites.length} of $beforeCount',
        );
      }

      // Merge with any pending offline data before setting state
      _mySites = await _mergeWithOfflineData(allSites);

      // Cache for offline use (only server data, not merged)
      await _cacheMySites(allSites);
    } catch (e) {
      debugPrint('[_loadMySites] Error loading my sites: $e');

      // Check if it's a network error - fall back to cache
      final errorStr = e.toString().toLowerCase();
      if (e is SocketException ||
          errorStr.contains('socketexception') ||
          errorStr.contains('failed host lookup') ||
          errorStr.contains('connection refused') ||
          errorStr.contains('network is unreachable') ||
          errorStr.contains('no address associated') ||
          errorStr.contains('connection timed out') ||
          errorStr.contains('errno = 7')) {
        debugPrint('[_loadMySites] Network error - falling back to cache');
        await _loadMySitesFromCache();
        return;
      }

      // Check if it's an auth error
      if (errorStr.contains('auth') ||
          errorStr.contains('unauthorized') ||
          errorStr.contains('jwt') ||
          errorStr.contains('token')) {
        debugPrint('[_loadMySites] Auth error - attempting session refresh');
        try {
          await supabase.auth.refreshSession();
        } catch (refreshError) {
          debugPrint('[_loadMySites] Session refresh failed: $refreshError');
        }
      }

      // Try cache as fallback
      if (_mySites.isEmpty) {
        await _loadMySitesFromCache();
      }
    }
  }

  Future<void> _cacheMySites(List<Map<String, dynamic>> sites) async {
    try {
      final offlineDb = OfflineDb();
      await offlineDb.cacheItem(
        OfflineDb.siteCacheBox,
        'my_sites_$_userId',
        data: {'sites': sites},
        ttl: const Duration(hours: 24),
      );
      debugPrint('[_cacheMySites] Cached ${sites.length} my sites');
    } catch (e) {
      debugPrint('[_cacheMySites] Error caching sites: $e');
    }
  }

  Future<void> _loadMySitesFromCache() async {
    try {
      final offlineDb = OfflineDb();
      final cachedItem = offlineDb.getCachedItem(
        OfflineDb.siteCacheBox,
        'my_sites_$_userId',
      );

      if (cachedItem != null && cachedItem.data != null) {
        final data = cachedItem.data;
        final sites = data['sites'] as List?;
        if (sites != null) {
          final cachedSites = sites.map((e) {
            try {
              return Map<String, dynamic>.from(e as Map);
            } catch (_) {
              return <String, dynamic>{};
            }
          }).where((e) => e.isNotEmpty).toList();
          // Merge with offline data when loading from cache
          _mySites = await _mergeWithOfflineData(cachedSites);
          debugPrint(
            '[_loadMySitesFromCache] Loaded ${_mySites.length} sites from cache (merged with offline)',
          );
        } else {
          _mySites = [];
        }
      } else {
        debugPrint('[_loadMySitesFromCache] No cached sites found');
        _mySites = [];
      }
    } catch (e) {
      debugPrint('[_loadMySitesFromCache] Error loading from cache: $e');
      _mySites = [];
    }
  }

  /// Build _mySites from the site_visits box when cache is empty (e.g. cold start offline).
  Future<void> _loadMySitesFromSiteVisitsBox() async {
    try {
      if (_userId == null) return;

      final offlineDb = OfflineDb();
      final allVisits = offlineDb.getAllSiteVisits();
      if (allVisits.isEmpty) {
        debugPrint('[_loadMySitesFromSiteVisitsBox] No site visits in box');
        return;
      }

      final bySite = <String, OfflineSiteVisit>{};
      for (final v in allVisits) {
        final existing = bySite[v.siteEntryId];
        final keepNew = existing == null ||
            _offlineVisitPriority(v.status) > _offlineVisitPriority(existing.status) ||
            (v.startedAt.isAfter(existing.startedAt) &&
                _offlineVisitPriority(v.status) == _offlineVisitPriority(existing.status));
        if (keepNew) {
          bySite[v.siteEntryId] = v;
        }
      }

      _mySites = bySite.values.map((v) => _offlineVisitToSiteMap(v)).toList();
      debugPrint(
        '[_loadMySitesFromSiteVisitsBox] Loaded ${_mySites.length} sites from site_visits box',
      );
    } catch (e) {
      debugPrint('[_loadMySitesFromSiteVisitsBox] Error: $e');
    }
  }

  int _offlineVisitPriority(String status) {
    switch (status.toLowerCase()) {
      case 'completed':
        return 3;
      case 'started':
      case 'draft':
        return 2;
      case 'accepted':
        return 1;
      default:
        return 0;
    }
  }

  Map<String, dynamic> _offlineVisitToSiteMap(OfflineSiteVisit v) {
    final status = v.status.toLowerCase();
    final String displayStatus;
    final String? visitStartedAt;
    final String? visitCompletedAt;
    if (status == 'completed') {
      displayStatus = 'Completed';
      visitStartedAt = v.startedAt.toIso8601String();
      visitCompletedAt = v.completedAt?.toIso8601String();
    } else if (status == 'draft' || status == 'started') {
      displayStatus = 'In Progress';
      visitStartedAt = v.startedAt.toIso8601String();
      visitCompletedAt = null;
    } else {
      displayStatus = 'Accepted';
      visitStartedAt = null;
      visitCompletedAt = null;
    }

    return {
      'id': v.siteEntryId,
      'site_name': v.siteName,
      'siteName': v.siteName,
      'site_code': v.siteCode,
      'siteCode': v.siteCode,
      'state': v.state,
      'locality': v.locality,
      'status': displayStatus,
      'visit_started_at': visitStartedAt,
      'visit_completed_at': visitCompletedAt,
      'visit_started_by': _userId,
      'accepted_by': _userId,
      'additional_data': {
        'start_location': v.startLocation,
        if (v.status == 'completed') 'end_location': v.endLocation,
      },
      '_offline_modified': true,
      '_synced': v.synced,
      if (v.status == 'draft' || v.status == 'started') '_isOfflineOnly': true,
    };
  }

  /// Safely parse additional_data which may be a JSON string or Map (e.g. from cache).
  Map<String, dynamic> _safeParseAdditionalData(dynamic data) {
    if (data is String) {
      try {
        final decoded = jsonDecode(data);
        return decoded is Map
            ? Map<String, dynamic>.from(decoded as Map)
            : {};
      } catch (_) {
        return {};
      }
    } else if (data is Map<String, dynamic>) {
      return Map<String, dynamic>.from(data);
    } else if (data is Map) {
      return Map<String, dynamic>.from(data);
    }
    return {};
  }

  /// Safely get a nested map (e.g. start_location) from additional_data.
  Map<String, dynamic>? _safeStartLocation(Map<String, dynamic> additionalData) {
    final raw = additionalData['start_location'];
    if (raw == null) return null;
    if (raw is Map) return Map<String, dynamic>.from(raw as Map);
    return null;
  }

  /// Merge server/cached sites with pending offline data from OfflineDb
  Future<List<Map<String, dynamic>>> _mergeWithOfflineData(
    List<Map<String, dynamic>> sites,
  ) async {
    try {
      final offlineDb = OfflineDb();
      final pendingVisits = offlineDb.getPendingSiteVisits();

      if (pendingVisits.isEmpty) {
        return sites;
      }

      debugPrint(
        '[_mergeWithOfflineData] Found ${pendingVisits.length} pending offline visits',
      );

      // Create a map of pending visits by siteEntryId for quick lookup
      final pendingMap = <String, OfflineSiteVisit>{};
      for (final visit in pendingVisits) {
        pendingMap[visit.siteEntryId] = visit;
      }

      // Merge offline data into sites
      final mergedSites = sites.map((site) {
        final siteId = site['id']?.toString();
        if (siteId == null) return site;

        final pendingVisit = pendingMap[siteId];
        if (pendingVisit == null) return site;

        // Merge offline data into the site
        final mergedSite = Map<String, dynamic>.from(site);
        mergedSite['_offline_modified'] = true;
        mergedSite['_synced'] = false;

        // Override status/category from offline visit so local changes are visible
        if (pendingVisit.status == 'completed') {
          mergedSite['status'] = 'Completed';
          mergedSite['_category'] = 'completed';
          if (pendingVisit.completedAt != null) {
            mergedSite['visit_completed_at'] = pendingVisit.completedAt!
                .toIso8601String();
          }
        } else if (pendingVisit.status == 'draft') {
          // Draft means started but not completed - should show as Ongoing
          mergedSite['status'] = 'Ongoing';
          mergedSite['_category'] = 'ongoing';
          mergedSite['visit_started_at'] = pendingVisit.startedAt
              .toIso8601String();
        }

        // Always normalize additional_data to a Map for consistent handling
        final additionalData = _safeParseAdditionalData(
          site['additional_data'],
        );

        // Preserve GPS coordinates from offline visit
        if (pendingVisit.startLocation != null) {
          additionalData['start_location'] = pendingVisit.startLocation;
        }

        // Always set the normalized additional_data
        mergedSite['additional_data'] = additionalData;

        // Preserve completion data
        if (pendingVisit.status == 'completed' ||
            pendingVisit.status == 'draft') {
          if (pendingVisit.notes != null) {
            mergedSite['_offline_notes'] = pendingVisit.notes;
          }
          if (pendingVisit.photos != null && pendingVisit.photos!.isNotEmpty) {
            mergedSite['_offline_photos'] = pendingVisit.photos;
          }
          if (pendingVisit.endLocation != null) {
            mergedSite['_offline_end_location'] = pendingVisit.endLocation;
          }
        }

        debugPrint(
          '[_mergeWithOfflineData] Merged offline data for site: $siteId (status: ${pendingVisit.status})',
        );
        return mergedSite;
      }).toList();

      return mergedSites;
    } catch (e) {
      debugPrint('[_mergeWithOfflineData] Error merging offline data: $e');
      return sites;
    }
  }

  Future<void> _loadUnsyncedCompletedVisits() async {
    // Load completed sites that don't have a synced report
    try {
      if (_userId == null) return;

      // First, get all completed sites
      final sitesResponse = await Supabase.instance.client
          .from('mmp_site_entries')
          .select('*, mmp_files(project_id)')
          .eq('accepted_by', _userId!)
          .ilike('status', 'Completed')
          .order('created_at', ascending: false)
          .limit(100);

      final allCompletedSites = (sitesResponse as List)
          .map((e) => e as Map<String, dynamic>)
          .toList();

      if (allCompletedSites.isEmpty) {
        _unsyncedCompletedVisits = [];
        return;
      }

      // Get all site IDs
      final siteIds = allCompletedSites
          .map((site) => site['id']?.toString())
          .where((id) => id != null && id.isNotEmpty)
          .cast<String>()
          .toList();

      // Check which sites have reports (query once for efficiency)
      final syncedSiteIds = <String>{}; // Sites with is_synced = true
      final sitesWithAnyReport = <String>{}; // Sites with any report (fallback)
      try {
        if (siteIds.isNotEmpty) {
          final reportsResponse = await Supabase.instance.client
              .from('reports')
              .select('site_visit_id, is_synced')
              .inFilter('site_visit_id', siteIds);

          if (reportsResponse is List) {
            debugPrint(
              '[_loadUnsyncedCompletedVisits] Found ${reportsResponse.length} reports for ${siteIds.length} sites',
            );
            for (final report in reportsResponse) {
              final siteId = report['site_visit_id']?.toString();
              if (siteId == null) continue;

              // Track all sites with any report (fallback check)
              sitesWithAnyReport.add(siteId);

              // Track sites with explicitly synced reports
              // is_synced defaults to false in schema, so null/false means unsynced
              final isSynced = report['is_synced'] as bool? ?? false;
              if (isSynced == true) {
                syncedSiteIds.add(siteId);
                debugPrint(
                  '[_loadUnsyncedCompletedVisits] Site $siteId has synced report (is_synced=true)',
                );
              } else {
                debugPrint(
                  '[_loadUnsyncedCompletedVisits] Site $siteId has report but is_synced=$isSynced',
                );
              }
            }
          } else {
            debugPrint(
              '[_loadUnsyncedCompletedVisits] No reports found or invalid response',
            );
          }
        }
      } catch (e) {
        debugPrint('[_loadUnsyncedCompletedVisits] Error querying reports: $e');
      }

      // Also check additional_data for visit_report_submitted flag (backup check)
      final sitesWithReportFlag = allCompletedSites
          .where((site) {
            final additionalData = _safeParseAdditionalData(
              site['additional_data'],
            );
            return additionalData['visit_report_submitted'] == true;
          })
          .map((site) => site['id']?.toString())
          .where((id) => id != null && id.isNotEmpty)
          .cast<String>()
          .toSet();

      // Combine all checks - if site has:
      // 1. Synced report (is_synced = true), OR
      // 2. visit_report_submitted flag, OR
      // 3. Any report at all (fallback for online completions where is_synced might not be set)
      // then it's considered synced
      final allSyncedSiteIds = syncedSiteIds
          .union(sitesWithReportFlag)
          .union(sitesWithAnyReport);

      debugPrint(
        '[_loadUnsyncedCompletedVisits] Total synced sites: ${allSyncedSiteIds.length} (explicitly synced: ${syncedSiteIds.length}, with flag: ${sitesWithReportFlag.length}, with any report: ${sitesWithAnyReport.length})',
      );

      // Filter for sites that are NOT synced
      List<Map<String, dynamic>> unsyncedSites = allCompletedSites.where((
        site,
      ) {
        final siteId = site['id']?.toString();
        if (siteId == null) return false;
        // Site is unsynced if it doesn't have a synced report
        return !allSyncedSiteIds.contains(siteId);
      }).toList();

      // Filter by project membership (for non-admin users)
      if (!_isAdminOrSuperUser) {
        final beforeCount = unsyncedSites.length;
        unsyncedSites = unsyncedSites.where((site) {
          final mmpFile = site['mmp_files'] as Map<String, dynamic>? ?? {};
          final projectId = mmpFile['project_id']?.toString();

          // If site has no project ID, exclude it
          if (projectId == null || projectId.isEmpty) {
            return false;
          }

          // Site must be in one of user's projects
          return _userProjectIds.contains(projectId);
        }).toList();

        debugPrint(
          'Filtered unsynced completed visits by project: ${unsyncedSites.length} of $beforeCount',
        );
      }

      _unsyncedCompletedVisits = unsyncedSites;
    } catch (e) {
      debugPrint('Error loading unsynced completed visits: $e');
    }
  }

  Future<void> _loadAdvanceRequests() async {
    try {
      if (_userId == null) return;

      if (!mounted) return;
      setState(() => _loadingAdvanceRequests = true);

      // Load all advance requests for this user
      final response = await Supabase.instance.client
          .from('down_payment_requests')
          .select('*')
          .eq('requested_by', _userId!)
          .order('created_at', ascending: false);

      // Map requests by site ID (keep most recent for each site)
      final requestsMap = <String, Map<String, dynamic>>{};
      for (final request in response) {
        final siteId =
            (request['mmp_site_entry_id'] as String?) ??
            (request['site_visit_id'] as String?);
        if (siteId != null && !requestsMap.containsKey(siteId)) {
          requestsMap[siteId] = request;
        }
      }

      if (!mounted) return;
      setState(() {
        _advanceRequests = requestsMap;
        _loadingAdvanceRequests = false;
      });
    } catch (e) {
      debugPrint('Error loading advance requests: $e');
      if (!mounted) return;
      setState(() {
        _advanceRequests = {};
        _loadingAdvanceRequests = false;
      });
    }
  }

  void _groupAvailableSites() {
    _groupedByStateLocality = {};
    for (final site in _availableSites) {
      final state = site['state'] as String? ?? 'Unknown State';
      final locality = site['locality'] as String? ?? 'Unknown Locality';
      final key = '$state - $locality';
      _groupedByStateLocality.putIfAbsent(key, () => []).add(site);
    }
  }

  Future<void> _loadCoordinatorData() async {
    try {
      if (_userId == null) return;

      // Load sites forwarded to this coordinator
      final response = await Supabase.instance.client
          .from('mmp_site_entries')
          .select('*, mmp_files(project_id)')
          .eq('forwarded_to_user_id', _userId!)
          .order('created_at', ascending: false)
          .limit(1000);

      List<Map<String, dynamic>> allCoordinatorSites = (response as List)
          .map((e) => e as Map<String, dynamic>)
          .toList();

      // Filter by project membership (for non-admin users)
      if (!_isAdminOrSuperUser) {
        final beforeCount = allCoordinatorSites.length;
        allCoordinatorSites = allCoordinatorSites.where((site) {
          final mmpFile = site['mmp_files'] as Map<String, dynamic>? ?? {};
          final projectId = mmpFile['project_id']?.toString();

          // If site has no project ID, exclude it
          if (projectId == null || projectId.isEmpty) {
            return false;
          }

          // Site must be in one of user's projects
          return _userProjectIds.contains(projectId);
        }).toList();

        debugPrint(
          'Filtered coordinator sites by project: ${allCoordinatorSites.length} of $beforeCount',
        );
      }

      _coordinatorSites = allCoordinatorSites;
    } catch (e) {
      debugPrint('Error loading coordinator data: $e');
    }
  }

  Future<void> _claimSite(Map<String, dynamic> site) async {
    debugPrint('[Claim] _claimSite called for site ${site['id']} (${site['site_name'] ?? site['siteName']})');
    try {
      if (_userId == null) return;

      // Show loading spinner while calculating
      if (mounted) {
        showDialog(
          context: context,
          barrierDismissible: false,
          builder: (BuildContext context) {
            return Center(
              child: Container(
                padding: const EdgeInsets.all(32),
                margin: const EdgeInsets.symmetric(horizontal: 40),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [Colors.white, Colors.blue.shade50],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(24),
                  boxShadow: [
                    BoxShadow(
                      color: AppColors.primaryBlue.withOpacity(0.3),
                      blurRadius: 20,
                      offset: const Offset(0, 10),
                    ),
                  ],
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    // Animated spinner with gradient border
                    Container(
                      width: 70,
                      height: 70,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: LinearGradient(
                          colors: [
                            AppColors.primaryBlue,
                            AppColors.primaryBlue.withOpacity(0.6),
                          ],
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: AppColors.primaryBlue.withOpacity(0.4),
                            blurRadius: 15,
                            offset: const Offset(0, 5),
                          ),
                        ],
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(4),
                        child: CircularProgressIndicator(
                          strokeWidth: 4,
                          valueColor: const AlwaysStoppedAnimation<Color>(
                            Colors.white,
                          ),
                          backgroundColor: Colors.white.withOpacity(0.3),
                        ),
                      ),
                    ),
                    const SizedBox(height: 24),
                    Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(
                          Icons.calculate_rounded,
                          color: AppColors.primaryBlue,
                          size: 22,
                        ),
                        const SizedBox(width: 10),
                        Text(
                          'Calculating fees',
                          style: GoogleFonts.poppins(
                            fontSize: 18,
                            fontWeight: FontWeight.w700,
                            color: AppColors.textDark,
                            letterSpacing: 0.3,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'Please wait...',
                      style: GoogleFonts.poppins(
                        fontSize: 13,
                        color: AppColors.textLight,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      }

      // Simulate calculation delay for better UX - 6 seconds
      await Future.delayed(const Duration(seconds: 6));

      // Calculate costs for the confirmation dialog
      final storedEnumeratorFee =
          (site['enumerator_fee'] as num?)?.toDouble() ?? 0.0;
      final transportFee = (site['transport_fee'] as num?)?.toDouble() ?? 0.0;
      final status = site['status'] ?? 'Pending';
      final isClaimableSite = status.toLowerCase() == 'dispatched';
      final enumeratorFee = (storedEnumeratorFee > 0)
          ? storedEnumeratorFee
          : (isClaimableSite ? _userEnumeratorFee : 0.0);
      final totalCost = enumeratorFee + transportFee;

      // Close loading spinner
      if (mounted) {
        Navigator.of(context).pop();
      }

      // Show confirmation dialog before claiming
      final confirmed = await _showClaimConfirmationDialog(
        site: site,
        totalCost: totalCost,
      );

      if (confirmed != true) {
        // User cancelled
        return;
      }

      // User confirmed - proceed with claim.
      // Match web ClaimSiteButton: send full params (fee + normalized role_scope) so backend
      // uses our values and does not SELECT from user_classifications (avoids enum error when DB has "enumerator").
      try {
        final feeService = ClaimFeeService();
        final breakdown = await feeService.calculateFeeForClaim(
          site['id'] as String,
          _userId!,
        );
        final transportFee = (site['transport_fee'] as num?)?.toDouble() ?? 0.0;
        final enumeratorFee = breakdown?.enumeratorFee ?? _userEnumeratorFee;
        final totalPayout = (breakdown?.totalPayout) ?? (enumeratorFee + transportFee);
        final roleScope = ClaimFeeService.normalizeRoleScopeForEnum(breakdown?.roleScope);

        final params = {
          'p_site_id': site['id'],
          'p_user_id': _userId!,
          'p_enumerator_fee': enumeratorFee,
          'p_total_cost': totalPayout,
          'p_classification_level': breakdown?.classificationLevel,
          'p_role_scope': roleScope,
          'p_fee_source': breakdown?.feeSource ?? 'default',
        };
        debugPrint('[Claim] Calling claim_site_visit RPC with params: $params');
        final result = await Supabase.instance.client.rpc(
          'claim_site_visit',
          params: params,
        );

        final claimResult = result as Map<String, dynamic>?;
        debugPrint('[Claim] RPC raw result: $claimResult');

        if (claimResult == null || (claimResult['success'] as bool?) != true) {
          String description =
              claimResult?['message'] as String? ?? 'Could not claim site';
          debugPrint(
            '[Claim] RPC returned failure: success=${claimResult?['success']}, '
            'message=${claimResult?['message']}, error=${claimResult?['error']}',
          );

          if (claimResult?['error'] == 'ALREADY_CLAIMED') {
            description =
                'Another enumerator claimed this site first. Try a different site.';
          } else if (claimResult?['error'] == 'CLAIM_IN_PROGRESS') {
            description =
                'Someone else is claiming this site right now. Try again in a moment.';
          }

          if (mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text(description), backgroundColor: Colors.red),
            );
          }
          return;
        }

        // RPC succeeded - now update to 'Accepted' so the site goes
        // directly to My Sites > Inbox (not the Assigned tab).
        try {
          final now = DateTime.now().toIso8601String();

          // Parse existing additional_data and add claim_type
          final additionalData = _safeParseAdditionalData(
            site['additional_data'],
          );
          additionalData['claim_type'] = 'self_claim';

          await Supabase.instance.client
              .from('mmp_site_entries')
              .update({
                'status': 'Accepted',
                'accepted_by': _userId,
                'accepted_at': now,
                'additional_data': additionalData,
                'cost_acknowledged': true,
                'cost_acknowledged_at': now,
                'cost_acknowledged_by': _userId,
                'updated_at': now,
              })
              .eq('id', site['id']);
          debugPrint(
            '[_claimSite] Follow-up update succeeded for site ${site['id']}',
          );
        } catch (updateError) {
          // Non-fatal: site is still claimed, just status might need manual fix
          debugPrint(
            '[_claimSite] Follow-up update failed for site ${site['id']}: $updateError',
          );
        }

        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Site claimed successfully'),
              backgroundColor: Colors.green,
            ),
          );
        }
      } catch (e, stack) {
        // RPC failed - log full error to trace enum/backend issues
        debugPrint('[Claim] RPC threw exception: $e');
        debugPrint('[Claim] Exception type: ${e.runtimeType}');
        debugPrint('[Claim] Stack trace: $stack');
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(
                e.toString().contains('already')
                    ? 'Could not claim this site. It may have been claimed by another enumerator.'
                    : 'Error claiming site: ${e.toString()}',
              ),
              backgroundColor: Colors.red,
            ),
          );
        }
        return;
      }

      // Reload data
      await _loadDataCollectorData();
      if (!mounted) return;
      setState(() {});
    } catch (e) {
      debugPrint('Error claiming site: $e');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error: ${e.toString()}'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  /// Show a confirmation dialog with total cost calculation before claiming a site
  Future<bool?> _showClaimConfirmationDialog({
    required Map<String, dynamic> site,
    required double totalCost,
  }) async {
    final siteName = site['site_name'] ?? site['siteName'] ?? 'Unknown Site';
    final siteCode = site['site_code'] ?? site['siteCode'] ?? 'N/A';
    final state = site['state'] ?? 'Unknown';
    final locality = site['locality'] ?? 'Unknown';
    final siteType = site['site_type'] ?? site['siteType'] ?? '';
    final hub = site['hub_name'] ?? site['hubName'] ?? site['hub_office'] ?? '';

    return showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return Dialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(24),
          ),
          elevation: 8,
          backgroundColor: Colors.transparent,
          insetPadding: const EdgeInsets.symmetric(
            horizontal: 16,
            vertical: 24,
          ),
          child: Container(
            constraints: const BoxConstraints(maxWidth: 400, maxHeight: 700),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(24),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.1),
                  blurRadius: 20,
                  offset: const Offset(0, 10),
                ),
              ],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Header with gradient background
                Container(
                  padding: const EdgeInsets.all(24),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        AppColors.primaryBlue,
                        AppColors.primaryBlue.withOpacity(0.85),
                      ],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: const BorderRadius.only(
                      topLeft: Radius.circular(24),
                      topRight: Radius.circular(24),
                    ),
                  ),
                  child: Column(
                    children: [
                      Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.all(12),
                            decoration: BoxDecoration(
                              color: Colors.white.withOpacity(0.2),
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: const Icon(
                              Icons.handshake_rounded,
                              color: Colors.white,
                              size: 28,
                            ),
                          ),
                          const SizedBox(width: 16),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  'Claim Site',
                                  style: GoogleFonts.poppins(
                                    fontSize: 22,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.white,
                                  ),
                                ),
                                Text(
                                  'Review assignment details',
                                  style: GoogleFonts.poppins(
                                    fontSize: 13,
                                    color: Colors.white.withOpacity(0.9),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),

                // Content - Wrapped in Flexible to prevent overflow
                Flexible(
                  child: SingleChildScrollView(
                    child: Padding(
                      padding: const EdgeInsets.all(24),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          // Site Name with icon
                          Row(
                            children: [
                              Container(
                                padding: const EdgeInsets.all(8),
                                decoration: BoxDecoration(
                                  color: AppColors.primaryBlue.withOpacity(0.1),
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: Icon(
                                  Icons.location_city_rounded,
                                  color: AppColors.primaryBlue,
                                  size: 20,
                                ),
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Text(
                                  siteName,
                                  style: GoogleFonts.poppins(
                                    fontSize: 18,
                                    fontWeight: FontWeight.bold,
                                    color: AppColors.textDark,
                                  ),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 20),

                          // Site Details Card
                          Container(
                            padding: const EdgeInsets.all(18),
                            decoration: BoxDecoration(
                              color: Colors.grey[50],
                              borderRadius: BorderRadius.circular(16),
                              border: Border.all(
                                color: Colors.grey[200]!,
                                width: 1,
                              ),
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  'SITE INFORMATION',
                                  style: GoogleFonts.poppins(
                                    fontSize: 11,
                                    fontWeight: FontWeight.w700,
                                    letterSpacing: 1,
                                    color: AppColors.textLight,
                                  ),
                                ),
                                const SizedBox(height: 16),

                                // Site Code
                                _buildSiteDetailRow(
                                  Icons.qr_code_rounded,
                                  'Site Code',
                                  siteCode,
                                ),
                                const SizedBox(height: 14),

                                // Location
                                _buildSiteDetailRow(
                                  Icons.location_on_rounded,
                                  'Location',
                                  '$locality, $state',
                                ),

                                // Hub (if available)
                                if (hub.isNotEmpty) ...[
                                  const SizedBox(height: 14),
                                  _buildSiteDetailRow(
                                    Icons.business_rounded,
                                    'Hub Office',
                                    hub,
                                  ),
                                ],

                                // Site Type (if available)
                                if (siteType.isNotEmpty) ...[
                                  const SizedBox(height: 14),
                                  _buildSiteDetailRow(
                                    Icons.category_rounded,
                                    'Site Type',
                                    siteType,
                                  ),
                                ],
                              ],
                            ),
                          ),

                          const SizedBox(height: 20),

                          // Total Payment Card - Eye-catching
                          Container(
                            padding: const EdgeInsets.all(24),
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [
                                  const Color(0xFF10B981),
                                  const Color(0xFF059669),
                                ],
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                              ),
                              borderRadius: BorderRadius.circular(16),
                              boxShadow: [
                                BoxShadow(
                                  color: const Color(
                                    0xFF10B981,
                                  ).withOpacity(0.4),
                                  blurRadius: 12,
                                  offset: const Offset(0, 6),
                                ),
                              ],
                            ),
                            child: Column(
                              children: [
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Icon(
                                      Icons.payments_rounded,
                                      color: Colors.white.withOpacity(0.9),
                                      size: 24,
                                    ),
                                    const SizedBox(width: 8),
                                    Text(
                                      'Total Payment',
                                      style: GoogleFonts.poppins(
                                        fontSize: 15,
                                        color: Colors.white.withOpacity(0.95),
                                        fontWeight: FontWeight.w600,
                                        letterSpacing: 0.5,
                                      ),
                                    ),
                                  ],
                                ),
                                const SizedBox(height: 12),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Padding(
                                      padding: const EdgeInsets.only(top: 6),
                                      child: Text(
                                        'SDG',
                                        style: GoogleFonts.poppins(
                                          fontSize: 18,
                                          fontWeight: FontWeight.w600,
                                          color: Colors.white.withOpacity(0.9),
                                        ),
                                      ),
                                    ),
                                    const SizedBox(width: 8),
                                    Text(
                                      totalCost.toStringAsFixed(0),
                                      style: GoogleFonts.poppins(
                                        fontSize: 48,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.white,
                                        height: 1.1,
                                      ),
                                    ),
                                  ],
                                ),
                                const SizedBox(height: 8),
                                Container(
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: 12,
                                    vertical: 6,
                                  ),
                                  decoration: BoxDecoration(
                                    color: Colors.white.withOpacity(0.2),
                                    borderRadius: BorderRadius.circular(20),
                                  ),
                                  child: Row(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      Icon(
                                        Icons.check_circle_rounded,
                                        size: 14,
                                        color: Colors.white.withOpacity(0.9),
                                      ),
                                      const SizedBox(width: 6),
                                      Text(
                                        'Upon visit completion',
                                        style: GoogleFonts.poppins(
                                          fontSize: 11,
                                          color: Colors.white.withOpacity(0.9),
                                          fontWeight: FontWeight.w500,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),

                          const SizedBox(height: 18),

                          // Info message
                          Container(
                            padding: const EdgeInsets.all(14),
                            decoration: BoxDecoration(
                              color: Colors.blue[50],
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(
                                color: Colors.blue[100]!,
                                width: 1,
                              ),
                            ),
                            child: Row(
                              children: [
                                Icon(
                                  Icons.info_rounded,
                                  color: Colors.blue[700],
                                  size: 20,
                                ),
                                const SizedBox(width: 12),
                                Expanded(
                                  child: Text(
                                    'By claiming this site, you commit to completing the visit and submitting the required report.',
                                    style: GoogleFonts.poppins(
                                      fontSize: 12,
                                      color: Colors.blue[900],
                                      height: 1.4,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),

                // Action Buttons
                Container(
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    color: Colors.grey[50],
                    borderRadius: const BorderRadius.only(
                      bottomLeft: Radius.circular(24),
                      bottomRight: Radius.circular(24),
                    ),
                  ),
                  child: Row(
                    children: [
                      Expanded(
                        child: OutlinedButton(
                          onPressed: () => Navigator.of(context).pop(false),
                          style: OutlinedButton.styleFrom(
                            foregroundColor: AppColors.textLight,
                            side: BorderSide(
                              color: Colors.grey[300]!,
                              width: 1.5,
                            ),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                            padding: const EdgeInsets.symmetric(vertical: 16),
                          ),
                          child: Text(
                            'Cancel',
                            style: GoogleFonts.poppins(
                              fontWeight: FontWeight.w600,
                              fontSize: 15,
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        flex: 2,
                        child: ElevatedButton(
                          onPressed: () => Navigator.of(context).pop(true),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: AppColors.primaryBlue,
                            foregroundColor: Colors.white,
                            elevation: 2,
                            shadowColor: AppColors.primaryBlue.withOpacity(0.5),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                            padding: const EdgeInsets.symmetric(vertical: 16),
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              const Icon(Icons.check_circle_rounded, size: 20),
                              const SizedBox(width: 8),
                              Text(
                                'Accept & Claim',
                                style: GoogleFonts.poppins(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 15,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  /// Helper method to build a site detail row in the dialog
  Widget _buildSiteDetailRow(IconData icon, String label, String value) {
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.all(6),
          decoration: BoxDecoration(
            color: AppColors.primaryBlue.withOpacity(0.1),
            borderRadius: BorderRadius.circular(6),
          ),
          child: Icon(icon, color: AppColors.primaryBlue, size: 18),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                label,
                style: GoogleFonts.poppins(
                  fontSize: 10,
                  fontWeight: FontWeight.w600,
                  color: AppColors.textLight,
                  letterSpacing: 0.5,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                value,
                style: GoogleFonts.poppins(
                  fontSize: 13,
                  fontWeight: FontWeight.w500,
                  color: AppColors.textDark,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  /// Reclaim a site - release it back to the dispatch pool (Admin/Super Admin only)
  Future<void> _reclaimSite(Map<String, dynamic> site) async {
    // Strict admin check - only admin/super_admin can reclaim
    final isAdminForReclaim =
        _userRole == 'admin' ||
        _userRole == 'super_admin' ||
        _userRole == 'superadmin';
    if (!isAdminForReclaim) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Only admins can reclaim sites'),
            backgroundColor: Colors.red,
          ),
        );
      }
      return;
    }

    final siteName = site['site_name'] ?? site['siteName'] ?? 'Unknown Site';
    final siteId = site['id'];

    // Show confirmation dialog
    final reason = await showDialog<String>(
      context: context,
      builder: (context) {
        final controller = TextEditingController();
        return AlertDialog(
          title: const Text('Reclaim Site'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Release "$siteName" back to the dispatch pool?'),
              const SizedBox(height: 16),
              TextField(
                controller: controller,
                decoration: const InputDecoration(
                  labelText: 'Reason for reclaim',
                  hintText: 'Enter reason...',
                  border: OutlineInputBorder(),
                ),
                maxLines: 2,
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () {
                if (controller.text.trim().isEmpty) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Please enter a reason')),
                  );
                  return;
                }
                Navigator.pop(context, controller.text.trim());
              },
              style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
              child: const Text(
                'Reclaim',
                style: TextStyle(color: Colors.white),
              ),
            ),
          ],
        );
      },
    );

    if (reason == null || reason.isEmpty) return;

    try {
      // Try using RPC first
      try {
        final result = await Supabase.instance.client.rpc(
          'reclaim_site_visit',
          params: {
            'p_site_id': siteId,
            'p_admin_id': _userId,
            'p_reason': reason,
          },
        );

        final reclaimResult = result as Map<String, dynamic>?;

        if (reclaimResult != null && reclaimResult['success'] == true) {
          if (mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text('Site "$siteName" reclaimed successfully'),
                backgroundColor: Colors.green,
              ),
            );
          }
          // Reload data
          await _loadDataCollectorData();
          if (mounted) setState(() {});
          return;
        } else {
          final errorMsg =
              reclaimResult?['message'] ?? 'Failed to reclaim site';
          throw Exception(errorMsg);
        }
      } catch (rpcError) {
        // RPC might not exist, fall back to direct update
        debugPrint(
          '[_reclaimSite] RPC failed, trying direct update: $rpcError',
        );

        // Direct update as fallback - clear ALL claim-related fields
        await Supabase.instance.client
            .from('mmp_site_entries')
            .update({
              'status': 'Dispatched',
              'accepted_by': null,
              'accepted_at': null,
              'visit_started_at': null,
              'visit_started_by': null,
              'enumerator_fee': null,
              'cost': null,
              'updated_at': DateTime.now().toIso8601String(),
            })
            .eq('id', siteId);

        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Site "$siteName" reclaimed successfully'),
              backgroundColor: Colors.green,
            ),
          );
        }

        // Reload data
        await _loadDataCollectorData();
        if (mounted) setState(() {});
      }
    } catch (e) {
      debugPrint('Error reclaiming site: $e');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error: ${e.toString()}'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  Future<void> _requestAdvance(Map<String, dynamic> site) async {
    try {
      if (_userId == null) return;

      final transportFee = (site['transport_fee'] as num?)?.toDouble() ?? 0.0;
      if (transportFee <= 0) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('This site has no transport fee'),
              backgroundColor: Colors.orange,
            ),
          );
        }
        return;
      }

      final siteName = site['site_name'] ?? site['siteName'] ?? 'Unknown Site';
      final hubId = site['hub_id'] ?? site['hubId'];
      final hubName =
          site['hub_name'] ??
          site['hubName'] ??
          site['hub_office'] ??
          site['hubOffice'];

      // Show request dialog
      final result = await showDialog<Map<String, dynamic>>(
        context: context,
        builder: (context) => RequestAdvanceDialog(
          site: site,
          transportationBudget: transportFee,
          hubId: hubId,
          hubName: hubName,
        ),
      );

      if (result == null || result['success'] != true) return;

      final requestedAmount = (result['requestedAmount'] as num).toDouble();
      final paymentType = result['paymentType'] as String;
      final justification = result['justification'] as String;

      // Properly convert installmentPlan from List<dynamic> to List<Map<String, dynamic>>
      List<Map<String, dynamic>> installmentPlan = [];
      if (result['installmentPlan'] != null) {
        final planList = result['installmentPlan'] as List?;
        if (planList != null && planList.isNotEmpty) {
          installmentPlan = planList
              .map((e) => e as Map<String, dynamic>)
              .toList();
        }
      }

      // Get user role
      final profile = await Supabase.instance.client
          .from('profiles')
          .select('role, hub_id')
          .eq('id', _userId!)
          .maybeSingle();

      final role = (profile?['role'] as String?)?.toLowerCase() ?? '';
      final requesterRole =
          (role == 'coordinator' ||
              role == 'field_coordinator' ||
              role == 'state_coordinator')
          ? 'coordinator'
          : 'dataCollector';

      final finalHubId = hubId ?? profile?['hub_id'] as String?;

      // Create advance request
      final newRequest = await Supabase.instance.client
          .from('down_payment_requests')
          .insert({
            'mmp_site_entry_id': site['id'],
            'site_name': siteName,
            'requested_by': _userId,
            'requester_role': requesterRole,
            'hub_id': finalHubId,
            'hub_name': hubName,
            'total_transportation_budget': transportFee,
            'requested_amount': requestedAmount,
            'payment_type': paymentType,
            'installment_plan': installmentPlan,
            'justification': justification,
            'supporting_documents': [],
            'status': 'pending_supervisor',
            'supervisor_status': 'pending',
          })
          .select()
          .single();

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text(
              'Advance request submitted successfully. Waiting for supervisor approval.',
            ),
            backgroundColor: Colors.green,
          ),
        );
      }

      // Reload advance requests
      await _loadAdvanceRequests();
      if (!mounted) return;
      setState(() {});
    } catch (e) {
      debugPrint('Error requesting advance: $e');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error: ${e.toString()}'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  bool _shouldShowRequestAdvance(Map<String, dynamic> site) {
    // Only show for accepted or in-progress sites owned by current user
    final status = (site['status'] as String? ?? '').toLowerCase();
    final isAcceptedOrOngoing =
        status == 'accepted' ||
        status == 'assigned' ||
        status == 'in progress' ||
        status == 'in_progress' ||
        status == 'ongoing';
    final isOwner = site['accepted_by'] == _userId;
    final transportFee = (site['transport_fee'] as num?)?.toDouble() ?? 0.0;
    final hasTransportBudget = transportFee > 0;

    return isAcceptedOrOngoing && isOwner && hasTransportBudget;
  }

  Widget _buildRequestAdvanceWidget(Map<String, dynamic> site) {
    final siteId = site['id'] as String? ?? '';
    final existingRequest = _advanceRequests[siteId];

    // If request exists, show status badge
    if (existingRequest != null) {
      return _buildAdvanceStatusBadge(existingRequest);
    }

    // Show Request Advance button
    final l10n = AppLocalizations.of(context);
    return ElevatedButton.icon(
      onPressed: () => _requestAdvance(site),
      icon: const Icon(Icons.payment, size: 18),
      label: Text(l10n?.requestAdvance ?? 'Request Advance'),
      style: ElevatedButton.styleFrom(
        backgroundColor: Colors.purple,
        foregroundColor: Colors.white,
        padding: const EdgeInsets.symmetric(vertical: 12),
      ),
    );
  }

  Widget _buildAdvanceStatusBadge(Map<String, dynamic> request) {
    final status = request['status'] as String? ?? 'pending_supervisor';
    final badgeInfo = AdvanceRequestService.getStatusBadge(status);
    final badgeColor = badgeInfo['color'] as Color;
    final badgeLabel = badgeInfo['label'] as String;
    final badgeIcon = badgeInfo['icon'] as IconData;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
      decoration: BoxDecoration(
        color: badgeColor.withOpacity(0.1),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: badgeColor.withOpacity(0.3)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(badgeIcon, size: 18, color: badgeColor),
          const SizedBox(width: 6),
          Flexible(
            child: Text(
              badgeLabel,
              style: GoogleFonts.poppins(
                fontSize: 12,
                fontWeight: FontWeight.w600,
                color: badgeColor,
              ),
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildActionButtons(
    Map<String, dynamic> site, {
    required String status,
    required bool showClaimButton,
    required bool showAcknowledgeButton,
    required bool showVisitActions,
  }) {
    final l10n = AppLocalizations.of(context);
    final buttons = <Widget>[];

    // Claim Button
    if (showClaimButton) {
      buttons.add(
        Expanded(
          child: ElevatedButton.icon(
            onPressed: () => _claimSite(site),
            icon: const Icon(Icons.handshake, size: 18),
            label: Text(l10n?.claimSite ?? 'Claim Site'),
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.primaryBlue,
              foregroundColor: Colors.white,
              padding: const EdgeInsets.symmetric(vertical: 12),
            ),
          ),
        ),
      );
    }

    // Acknowledge Cost Button
    if (showAcknowledgeButton) {
      buttons.add(
        Expanded(
          child: ElevatedButton.icon(
            onPressed: () => _acknowledgeCost(site),
            icon: const Icon(Icons.check_circle, size: 18),
            label: Text(l10n?.acknowledgeCost ?? 'Acknowledge Cost'),
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.orange,
              foregroundColor: Colors.white,
              padding: const EdgeInsets.symmetric(vertical: 12),
            ),
          ),
        ),
      );
    }

    // Visit Actions
    if (showVisitActions) {
      // Request Advance Button (for accepted/in-progress sites with transport fee)
      if (_shouldShowRequestAdvance(site)) {
        buttons.add(Expanded(child: _buildRequestAdvanceWidget(site)));
      }

      // Start Visit Button (for accepted/assigned sites) - now shows even if Request Advance is shown
      if ((status.toString().toLowerCase() == 'accepted' ||
              status.toString().toLowerCase() == 'assigned') &&
          site['accepted_by'] == _userId) {
        buttons.add(
          Expanded(
            child: ElevatedButton.icon(
              onPressed: () => _startVisit(site),
              icon: const Icon(Icons.play_arrow, size: 18),
              label: Text(l10n?.startVisit ?? 'Start Visit'),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.green,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 12),
              ),
            ),
          ),
        );
      }

      // Complete Visit Button
      if ((status.toString().toLowerCase() == 'in progress' ||
              status.toString().toLowerCase() == 'ongoing') &&
          site['accepted_by'] == _userId) {
        buttons.add(
          Expanded(
            child: ElevatedButton.icon(
              onPressed: () => _completeVisit(site),
              icon: const Icon(Icons.check, size: 18),
              label: Text(l10n?.completeVisit ?? 'Complete'),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.green,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 12),
              ),
            ),
          ),
        );
      }

      // View Report Button for completed visits (Admin/FOM/ICT only)
      if ((status.toString().toLowerCase() == 'completed' ||
          status.toString().toLowerCase() == 'complete')) {
        final canViewReport =
            _isAdminOrSuperUser || _userRole == 'fom' || _userRole == 'ict';
        if (canViewReport) {
          buttons.add(
            Expanded(
              child: ElevatedButton.icon(
                onPressed: () => _viewVisitReport(site),
                icon: const Icon(Icons.visibility, size: 18),
                label: Text(l10n?.viewReport ?? 'View Report'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blue,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 12),
                ),
              ),
            ),
          );
        }
      }
    }

    // Reclaim Button (Admin/Super Admin only) - for claimed/accepted sites that belong to other users
    // More restrictive than _isAdminOrSuperUser - only true admins can reclaim
    final isAdminForReclaim =
        _userRole == 'admin' ||
        _userRole == 'super_admin' ||
        _userRole == 'superadmin';
    if (isAdminForReclaim) {
      final statusLower = status.toLowerCase().replaceAll(' ', '_');
      final acceptedBy = site['accepted_by']?.toString();
      final isClaimedOrAccepted =
          statusLower == 'claimed' ||
          statusLower == 'accepted' ||
          statusLower == 'assigned' ||
          statusLower == 'in_progress' ||
          statusLower == 'ongoing';
      final isOtherUser = acceptedBy != null && acceptedBy != _userId;

      if (isClaimedOrAccepted && isOtherUser) {
        buttons.add(
          Expanded(
            child: ElevatedButton.icon(
              onPressed: () => _reclaimSite(site),
              icon: const Icon(Icons.rotate_left, size: 18),
              label: Text(l10n?.reclaimSite ?? 'Reclaim'),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 12),
              ),
            ),
          ),
        );
      }
    }

    if (buttons.isEmpty) return const SizedBox.shrink();

    // Use Row with Expanded widgets - they'll share space equally
    return Row(children: buttons);
  }

  // ==================== CALL AND MESSAGE FUNCTIONALITY ====================

  /// Make a phone call to a contact
  Future<void> _makeCall(String phoneNumber) async {
    final cleanPhone = phoneNumber.replaceAll(RegExp(r'[^\d+]'), '');
    final uri = Uri.parse('tel:$cleanPhone');
    try {
      if (await canLaunchUrl(uri)) {
        await launchUrl(uri);
      } else {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Cannot make phone calls on this device'),
              backgroundColor: Colors.orange,
            ),
          );
        }
      }
    } catch (e) {
      debugPrint('[_makeCall] Error: $e');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Failed to make call: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  /// Send an SMS message to a contact
  Future<void> _sendSMS(String phoneNumber, {String? message}) async {
    final cleanPhone = phoneNumber.replaceAll(RegExp(r'[^\d+]'), '');
    final uri = message != null
        ? Uri.parse('sms:$cleanPhone?body=${Uri.encodeComponent(message)}')
        : Uri.parse('sms:$cleanPhone');
    try {
      if (await canLaunchUrl(uri)) {
        await launchUrl(uri);
      } else {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Cannot send SMS on this device'),
              backgroundColor: Colors.orange,
            ),
          );
        }
      }
    } catch (e) {
      debugPrint('[_sendSMS] Error: $e');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Failed to send SMS: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  /// Open WhatsApp chat with a contact
  Future<void> _openWhatsApp(String phoneNumber, {String? message}) async {
    // Remove any non-digit characters except +
    String cleanPhone = phoneNumber.replaceAll(RegExp(r'[^\d+]'), '');

    // Handle country codes properly
    if (cleanPhone.startsWith('+')) {
      // Already has country code, just remove the +
      cleanPhone = cleanPhone.substring(1);
    } else if (cleanPhone.startsWith('00')) {
      // International format with 00 prefix
      cleanPhone = cleanPhone.substring(2);
    } else if (cleanPhone.startsWith('0')) {
      // Local number - assume Sudan country code (249)
      cleanPhone = '249${cleanPhone.substring(1)}';
    }
    // If it's just digits without any prefix and has 9+ digits, assume it already has country code

    final uri = message != null
        ? Uri.parse(
            'https://wa.me/$cleanPhone?text=${Uri.encodeComponent(message)}',
          )
        : Uri.parse('https://wa.me/$cleanPhone');

    try {
      if (await canLaunchUrl(uri)) {
        await launchUrl(uri, mode: LaunchMode.externalApplication);
      } else {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('WhatsApp is not installed'),
              backgroundColor: Colors.orange,
            ),
          );
        }
      }
    } catch (e) {
      debugPrint('[_openWhatsApp] Error: $e');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Failed to open WhatsApp: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  /// Initiate an in-app Agora call to a PACT user
  Future<void> _initiateInAppCall(
    String targetUserId,
    String targetUserName, {
    bool isAudioOnly = true,
  }) async {
    try {
      final agoraService = AgoraCallService();

      // Check if user is logged in
      if (_userId == null) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Unable to initiate call. Please try again.'),
              backgroundColor: Colors.red,
            ),
          );
        }
        return;
      }

      // Check if already in a call
      if (agoraService.isInCall) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('You are already in a call'),
              backgroundColor: Colors.orange,
            ),
          );
        }
        return;
      }

      // Start Agora call (service initialized at app startup in main_screen.dart)
      final result = await agoraService.startCall(
        remoteUserId: targetUserId,
        remoteUserName: targetUserName,
        audioOnly: isAudioOnly,
      );

      if (result.success && result.channelName != null && mounted) {
        Navigator.of(context).push(
          MaterialPageRoute(
            builder: (context) => AgoraCallScreen(
              channelName: result.channelName!,
              remoteUserId: targetUserId,
              remoteUserName: targetUserName,
              isAudioOnly: isAudioOnly,
              isOutgoing: true,
            ),
          ),
        );
      } else if (mounted) {
        final message = result.error ?? 'Unable to connect call';
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(message), backgroundColor: Colors.orange),
        );
      }
    } catch (e) {
      debugPrint('[_initiateInAppCall] Error: $e');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Failed to start call: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  /// Build contact buttons row for a site
  Widget _buildContactButtons(Map<String, dynamic> site) {
    // Try to get phone number from various possible fields
    final phone =
        site['contact_phone'] ??
        site['phone'] ??
        site['phone_number'] ??
        site['enumerator_phone'] ??
        site['assigned_phone'];

    // Check if contact is a PACT user (has user_id)
    final contactUserId =
        site['accepted_by'] ??
        site['assigned_to'] ??
        site['enumerator_id'] ??
        site['coordinator_id'];
    final contactName =
        site['enumerator_name'] ??
        site['assigned_name'] ??
        site['coordinator_name'] ??
        'PACT User';
    final isPactUser =
        contactUserId != null && contactUserId.toString().isNotEmpty;

    // If no phone and not a PACT user, don't show buttons
    if ((phone == null || phone.toString().isEmpty) && !isPactUser) {
      return const SizedBox.shrink();
    }

    final phoneStr = phone?.toString() ?? '';
    final siteName = site['site_name'] ?? site['siteName'] ?? 'Site';

    return Container(
      margin: const EdgeInsets.only(top: 8),
      child: Column(
        children: [
          // In-App Call button removed per user request - use Communications screen instead
          // External contact buttons (Phone, SMS, WhatsApp)
          if (phoneStr.isNotEmpty)
            Builder(
              builder: (context) {
                final l10n = AppLocalizations.of(context);
                return Row(
                  children: [
                    // Call Button (native phone)
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: () => _makeCall(phoneStr),
                        icon: const Icon(Icons.phone, size: 16),
                        label: Text(l10n?.call ?? 'Call'),
                        style: OutlinedButton.styleFrom(
                          foregroundColor: Colors.green,
                          side: const BorderSide(color: Colors.green),
                          padding: const EdgeInsets.symmetric(vertical: 8),
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    // SMS Button
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: () => _sendSMS(
                          phoneStr,
                          message: 'Regarding site visit: $siteName',
                        ),
                        icon: const Icon(Icons.message, size: 16),
                        label: Text(l10n?.sms ?? 'SMS'),
                        style: OutlinedButton.styleFrom(
                          foregroundColor: Colors.blue,
                          side: const BorderSide(color: Colors.blue),
                          padding: const EdgeInsets.symmetric(vertical: 8),
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    // WhatsApp Button
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: () => _openWhatsApp(
                          phoneStr,
                          message: 'Hello, regarding site visit: $siteName',
                        ),
                        icon: const Icon(Icons.chat, size: 16),
                        label: Text(l10n?.whatsapp ?? 'WhatsApp'),
                        style: OutlinedButton.styleFrom(
                          foregroundColor: const Color(0xFF25D366),
                          side: const BorderSide(color: Color(0xFF25D366)),
                          padding: const EdgeInsets.symmetric(vertical: 8),
                        ),
                      ),
                    ),
                  ],
                );
              },
            ),
        ],
      ),
    );
  }

  /// Store an accepted site in the OfflineDb site_visits box so that it can
  /// still appear under My Sites after a cold offline restart.
  Future<void> _saveAcceptedVisitOffline(Map<String, dynamic> site) async {
    try {
      if (_userId == null) return;

      final siteId = site['id']?.toString();
      if (siteId == null || siteId.isEmpty) return;

      final offlineDb = OfflineDb();
      final now = DateTime.now();

      final siteName =
          site['site_name']?.toString() ?? site['siteName']?.toString() ?? 'Unknown Site';
      final siteCode =
          site['site_code']?.toString() ?? site['siteCode']?.toString() ?? '';
      final state = site['state']?.toString() ?? '';
      final locality = site['locality']?.toString() ?? '';

      final offlineVisit = OfflineSiteVisit(
        id: 'accepted_${siteId}_${now.millisecondsSinceEpoch}',
        siteEntryId: siteId,
        siteName: siteName,
        siteCode: siteCode,
        state: state,
        locality: locality,
        status: 'accepted',
        startedAt: now,
        synced: true,
      );

      await offlineDb.saveSiteVisitOffline(offlineVisit);
      debugPrint(
        '[_saveAcceptedVisitOffline] Stored accepted site offline: $siteId ($siteName)',
      );
    } catch (e) {
      debugPrint('[_saveAcceptedVisitOffline] Error storing accepted site: $e');
    }
  }

  Future<void> _acknowledgeCost(Map<String, dynamic> site) async {
    // Show cost acknowledgment dialog
    final acknowledged = await showDialog<bool>(
      context: context,
      builder: (context) => _CostAcknowledgmentDialog(site: site),
    );

    if (acknowledged != true) return;

    try {
      final now = DateTime.now().toIso8601String();

      await Supabase.instance.client
          .from('mmp_site_entries')
          .update({
            'status': 'accepted',
            'cost_acknowledged': true,
            'cost_acknowledged_at': now,
            'cost_acknowledged_by': _userId,
            'accepted_at': now,
            'accepted_by': _userId,
            'updated_at': now,
            'additional_data': {
              ..._safeParseAdditionalData(site['additional_data']),
              'cost_acknowledged': true,
              'cost_acknowledged_at': now,
              'cost_acknowledged_by': _userId,
            },
          })
          .eq('id', site['id']);

      await _saveAcceptedVisitOffline(site);

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Cost acknowledged. Site moved to My Sites.'),
            backgroundColor: Colors.green,
          ),
        );
      }

      await _loadDataCollectorData();
      if (!mounted) return;
      setState(() {});
    } catch (e) {
      debugPrint('Error acknowledging cost: $e');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error: ${e.toString()}'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  Future<void> _startVisit(Map<String, dynamic> site) async {
    final supabase = Supabase.instance.client;

    try {
      // Check connectivity first
      final connectivity = await Connectivity().checkConnectivity();
      final isOffline = connectivity.contains(ConnectivityResult.none);

      debugPrint('[_startVisit] Connectivity check - offline: $isOffline');

      // Check location permissions
      final hasPermission = await LocationService.checkPermissions();
      if (!hasPermission) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text(
                'Location permission is required to start a visit.',
              ),
              backgroundColor: Colors.red,
            ),
          );
        }
        return;
      }

      // Show confirmation dialog
      final confirmed = await showDialog<bool>(
        context: context,
        builder: (context) => StartVisitDialog(site: site),
      );

      if (confirmed != true) return;

      // Get current location (works offline - uses device GPS)
      final position = await LocationService.getCurrentLocation();
      if (position == null) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text(
                'Could not get location. Visit will start without location.',
              ),
              backgroundColor: Colors.orange,
            ),
          );
        }
      }

      final now = DateTime.now().toIso8601String();
      final siteStatus = (site['status'] as String? ?? '').toLowerCase();
      final isAssigned =
          siteStatus == 'assigned' && site['accepted_by'] == null;

      // Calculate fees from cached data (works offline)
      final enumeratorFee = (site['enumerator_fee'] as num?)?.toDouble() ?? 0.0;
      final transportFee = (site['transport_fee'] as num?)?.toDouble() ?? 0.0;
      final calculatedCost = enumeratorFee + transportFee;

      // Build update data
      final updateData = <String, dynamic>{
        'status': 'In Progress',
        'visit_started_at': now,
        'visit_started_by': _userId,
        'updated_at': now,
      };

      // Add location to additional_data if available
      if (position != null) {
        final additionalData = _safeParseAdditionalData(
          site['additional_data'],
        );
        additionalData['start_location'] = {
          'latitude': position.latitude,
          'longitude': position.longitude,
          'accuracy': position.accuracy,
          'timestamp': now,
        };
        updateData['additional_data'] = additionalData;
      }

      // If site was "assigned" (not yet accepted), auto-accept and set fees
      if (isAssigned) {
        updateData['accepted_by'] = _userId;
        updateData['accepted_at'] = now;
        if (enumeratorFee > 0 || calculatedCost > 0) {
          updateData['enumerator_fee'] = enumeratorFee;
          updateData['transport_fee'] = transportFee;
          updateData['cost'] = calculatedCost;
        }
      }

      // OFFLINE MODE: Queue for sync and update local cache
      if (isOffline) {
        debugPrint('[_startVisit] Offline mode - saving locally');

        // Build start location from GPS
        final startLocation = position != null
            ? {
                'latitude': position.latitude,
                'longitude': position.longitude,
                'accuracy': position.accuracy,
              }
            : <String, dynamic>{};

        // Queue using OfflineDb with site metadata
        final offlineDb = OfflineDb();
        await offlineDb.queueStartVisit(
          visitId: site['id'].toString(),
          userId: _userId ?? '',
          startLocation: startLocation,
          siteName:
              site['site_name']?.toString() ?? site['siteName']?.toString(),
          siteCode:
              site['site_code']?.toString() ?? site['siteCode']?.toString(),
          state: site['state']?.toString(),
          locality: site['locality']?.toString(),
        );

        // Note: Don't call forceSync while offline - SyncManager will pick up pending actions
        // when connectivity is restored via auto-sync

        // Update local cache
        final updatedSite = Map<String, dynamic>.from(site);
        updatedSite.addAll(updateData);
        updatedSite['_offline_modified'] = true;
        updatedSite['_synced'] = false;

        // Update in _mySites list
        final siteIndex = _mySites.indexWhere((s) => s['id'] == site['id']);
        if (siteIndex != -1) {
          _mySites[siteIndex] = updatedSite;
        }

        if (mounted) {
          setState(() {});
          // Go straight to Complete Visit dialog
          await _completeVisit(updatedSite);
        }
        return;
      }

      // ONLINE MODE: Validate session and update database
      final session = supabase.auth.currentSession;
      debugPrint(
        '[_startVisit] Session check - valid: ${session != null}, expired: ${session?.isExpired ?? true}',
      );

      if (session == null || session.isExpired) {
        debugPrint(
          '[_startVisit] Session expired or missing, attempting refresh...',
        );
        try {
          await supabase.auth.refreshSession();
          debugPrint('[_startVisit] Session refreshed successfully');
        } catch (refreshError) {
          debugPrint('[_startVisit] Session refresh failed: $refreshError');
          // Fall back to offline mode
          debugPrint('[_startVisit] Falling back to offline mode');
          final startLocation = position != null
              ? {
                  'latitude': position.latitude,
                  'longitude': position.longitude,
                  'accuracy': position.accuracy,
                }
              : <String, dynamic>{};
          final offlineDb = OfflineDb();
          await offlineDb.queueStartVisit(
            visitId: site['id'].toString(),
            userId: _userId ?? '',
            startLocation: startLocation,
            siteName:
                site['site_name']?.toString() ?? site['siteName']?.toString(),
            siteCode:
                site['site_code']?.toString() ?? site['siteCode']?.toString(),
            state: site['state']?.toString(),
            locality: site['locality']?.toString(),
          );
          if (mounted) {
            final updatedSite = Map<String, dynamic>.from(site);
            updatedSite.addAll(updateData);
            updatedSite['_offline_modified'] = true;
            updatedSite['_synced'] = false;
            await _completeVisit(updatedSite);
          }
          return;
        }
      }

      // Re-check user ID after potential refresh
      final userId = supabase.auth.currentUser?.id;
      if (userId == null) {
        debugPrint('[_startVisit] User ID is null after session check');
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Authentication error. Please log in again.'),
              backgroundColor: Colors.red,
            ),
          );
        }
        return;
      }

      // Update database
      try {
        await supabase
            .from('mmp_site_entries')
            .update(updateData)
            .eq('id', site['id']);
        debugPrint('[_startVisit] Database update successful');
      } catch (dbError) {
        debugPrint('[_startVisit] Database error: $dbError');
        // Check if it's a network error - queue offline
        final errorStr = dbError.toString().toLowerCase();
        if (errorStr.contains('socket') ||
            errorStr.contains('network') ||
            errorStr.contains('host lookup') ||
            errorStr.contains('connection')) {
          debugPrint('[_startVisit] Network error - queueing offline');
          final startLocation = position != null
              ? {
                  'latitude': position.latitude,
                  'longitude': position.longitude,
                  'accuracy': position.accuracy,
                }
              : <String, dynamic>{};
          final offlineDb = OfflineDb();
          await offlineDb.queueStartVisit(
            visitId: site['id'].toString(),
            userId: _userId ?? '',
            startLocation: startLocation,
            siteName:
                site['site_name']?.toString() ?? site['siteName']?.toString(),
            siteCode:
                site['site_code']?.toString() ?? site['siteCode']?.toString(),
            state: site['state']?.toString(),
            locality: site['locality']?.toString(),
          );
          if (mounted) {
            final updatedSite = Map<String, dynamic>.from(site);
            updatedSite.addAll(updateData);
            updatedSite['_offline_modified'] = true;
            updatedSite['_synced'] = false;
            await _completeVisit(updatedSite);
          }
          return;
        }
        // Check if it's an auth-related error
        if (errorStr.contains('auth') ||
            errorStr.contains('unauthorized') ||
            errorStr.contains('jwt') ||
            errorStr.contains('token')) {
          debugPrint('[_startVisit] Auth-related database error detected');
          // Try to refresh session and retry once
          try {
            await supabase.auth.refreshSession();
            await supabase
                .from('mmp_site_entries')
                .update(updateData)
                .eq('id', site['id']);
            debugPrint('[_startVisit] Retry after session refresh successful');
          } catch (retryError) {
            debugPrint('[_startVisit] Retry after refresh failed: $retryError');
            throw Exception('Authentication error. Please log in again.');
          }
        } else {
          rethrow;
        }
      }

      // Build updated site and go straight to Complete Visit dialog
      if (mounted) {
        final updatedSite = Map<String, dynamic>.from(site);
        updatedSite.addAll(updateData);
        await _completeVisit(updatedSite);
      }
    } catch (e) {
      debugPrint('[_startVisit] Error starting visit: $e');

      // Check session state after error
      final sessionAfterError = supabase.auth.currentSession;
      debugPrint(
        '[_startVisit] Session after error - valid: ${sessionAfterError != null}',
      );

      if (mounted) {
        final errorMessage =
            e.toString().contains('Authentication') ||
                e.toString().contains('Session expired')
            ? 'Authentication error. Please log in again.'
            : 'Error: ${e.toString()}';

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(errorMessage), backgroundColor: Colors.red),
        );
      }
    }
  }

  Future<void> _completeVisit(Map<String, dynamic> site) async {
    final result = await CompleteVisitFlow.run(
      context,
      site: site,
      userId: _userId,
      onOnlineSuccessReload: () async {
        await _loadAvailableSites();
        await _loadMySites();
        if (mounted) setState(() {});
      },
    );
    if (result == null) return;
    if (result.updatedSite != null) {
      final siteIndex = _mySites.indexWhere((s) => s['id'] == site['id']);
      if (siteIndex != -1) {
        _mySites[siteIndex] = result.updatedSite!;
      }
      if (result.isOffline) {
        _unsyncedCompletedVisits.add(result.updatedSite!);
      }
      if (mounted) setState(() {});
    }
  }

  /// Check if a site has a synced report (fully synced to server; belongs in Sent).
  /// Returns false for offline-only completions (they belong in Outbox until sync runs).
  bool _hasSyncedReport(Map<String, dynamic> site) {
    final siteId = site['id']?.toString();
    if (siteId == null) return false;

    // Offline-only completion: merged from pending offline visit, not yet synced to server.
    // These must show in Outbox, not Sent.
    if (site['_offline_modified'] == true || site['_synced'] == false) {
      return false;
    }

    // Check if site is in unsynced list (server Completed but no report)
    final isUnsynced = _unsyncedCompletedVisits.any(
      (uv) => uv['id']?.toString() == siteId,
    );
    if (isUnsynced) return false;

    // Positive evidence from server: report was submitted and synced
    final additionalData = _safeParseAdditionalData(site['additional_data']);
    if (additionalData['visit_report_submitted'] == true) {
      return true;
    }
    if (additionalData['visit_report_id'] != null) {
      return true;
    }

    // Do not assume synced just because status is completed and not in unsynced list
    // (that wrongly put offline-only completions in Sent). Require report evidence above.
    return false;
  }

  List<Map<String, dynamic>> _getFilteredSites(
    List<Map<String, dynamic>> sites,
  ) {
    if (_searchQuery.isEmpty) return sites;

    final query = _searchQuery.toLowerCase();
    return sites.where((site) {
      final siteName = (site['site_name'] ?? site['siteName'] ?? '')
          .toString()
          .toLowerCase();
      final siteCode = (site['site_code'] ?? site['siteCode'] ?? '')
          .toString()
          .toLowerCase();
      final state = (site['state'] ?? '').toString().toLowerCase();
      final locality = (site['locality'] ?? '').toString().toLowerCase();

      return siteName.contains(query) ||
          siteCode.contains(query) ||
          state.contains(query) ||
          locality.contains(query);
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    return MainLayout(
      currentIndex: 1, // MMP is typically index 1
      child: Scaffold(
        key: _scaffoldKey,
        backgroundColor: AppColors.backgroundGray,
        drawer: CustomDrawerMenu(
          currentUser: Supabase.instance.client.auth.currentUser,
          onClose: () => _scaffoldKey.currentState?.closeDrawer(),
        ),
        body: SafeArea(
          child: Column(
            children: [
              ReusableAppBar(
                title:
                    AppLocalizations.of(context)?.mmpManagement ??
                    'MMP Management',
                scaffoldKey: _scaffoldKey,
                showLanguageSwitcher: true,
                showNotifications: true,
                onNotificationTap: () => NotificationsPanel.show(context),
                showUserAvatar: true,
              ),
              Expanded(
                child: _isLoading
                    ? const Center(child: CircularProgressIndicator())
                    : (_isDataCollector || _isCoordinator)
                    ? _buildDataCollectorView()
                    : _buildNoAccessView(),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildNoAccessView() {
    final l10n = AppLocalizations.of(context);
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.lock_outline, size: 64, color: AppColors.textLight),
            const SizedBox(height: 16),
            Text(
              l10n?.accessDenied ?? 'Access Denied',
              style: GoogleFonts.poppins(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: AppColors.textDark,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              l10n?.noPermission ??
                  'You don\'t have permission to access this page.',
              style: GoogleFonts.poppins(
                fontSize: 14,
                color: AppColors.textLight,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDataCollectorView() {
    final l10n = AppLocalizations.of(context);
    return Column(
      children: [
        // Header
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [Color(0xFF2563EB), Color(0xFF1E40AF)],
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.blue.withOpacity(0.3),
                blurRadius: 10,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: const Icon(
                      Icons.assignment,
                      color: Colors.white,
                      size: 24,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          l10n?.myAssignments ?? 'My Assignments',
                          style: GoogleFonts.poppins(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                          ),
                        ),
                        Text(
                          l10n?.claimManageComplete ??
                              'Claim, manage, and complete site visits',
                          style: GoogleFonts.poppins(
                            fontSize: 12,
                            color: Colors.white.withOpacity(0.9),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),

        // Search Bar
        Padding(
          padding: const EdgeInsets.all(16),
          child: TextField(
            controller: _searchController,
            onChanged: (value) {
              setState(() => _searchQuery = value);
            },
            decoration: InputDecoration(
              hintText: l10n?.searchSites ?? 'Search sites...',
              prefixIcon: const Icon(Icons.search),
              suffixIcon: _searchQuery.isNotEmpty
                  ? IconButton(
                      icon: const Icon(Icons.clear),
                      onPressed: () {
                        _searchController.clear();
                        setState(() => _searchQuery = '');
                      },
                    )
                  : null,
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              filled: true,
              fillColor: Colors.white,
            ),
          ),
        ),

        // Tabs
        Container(
          color: Colors.white,
          child: Column(
            children: [
              Row(
                children: [
                  Expanded(
                    child: _buildTabButton(
                      'claimable',
                      l10n?.claimable ?? 'Claimable',
                      Icons.handshake,
                      _availableSites.length,
                    ),
                  ),
                  Expanded(
                    child: _buildTabButton(
                      'assigned',
                      l10n?.assigned ?? 'Assigned',
                      Icons.assignment,
                      _smartAssignedSites.length,
                    ),
                  ),
                  Expanded(
                    child: _buildTabButton(
                      'my-sites',
                      l10n?.mySites ?? 'My Sites',
                      Icons.location_on,
                      _mySites.length,
                    ),
                  ),
                ],
              ),
              if (_enumeratorSubTab == 'my-sites') ...[
                const Divider(height: 1),
                Row(
                  children: [
                    Expanded(
                      child: _buildSubTabButton(
                        'pending',
                        l10n?.inbox ?? 'Inbox',
                        _getPendingCount(),
                      ),
                    ),
                    Expanded(
                      child: _buildSubTabButton(
                        'drafts',
                        l10n?.drafts ?? 'Drafts',
                        _getDraftsCount(),
                      ),
                    ),
                    Expanded(
                      child: _buildSubTabButton(
                        'outbox',
                        l10n?.outbox ?? 'Outbox',
                        _getOutboxCount(),
                      ),
                    ),
                    Expanded(
                      child: _buildSubTabButton(
                        'sent',
                        l10n?.sent ?? 'Sent',
                        _getSentCount(),
                      ),
                    ),
                  ],
                ),
              ],
            ],
          ),
        ),

        // Content
        Expanded(child: _buildDataCollectorContent()),
      ],
    );
  }

  Widget _buildTabButton(String tab, String label, IconData icon, int count) {
    final isActive = _enumeratorSubTab == tab;
    return InkWell(
      onTap: () => setState(() => _enumeratorSubTab = tab),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
          border: Border(
            bottom: BorderSide(
              color: isActive ? AppColors.primaryBlue : Colors.transparent,
              width: 2,
            ),
          ),
        ),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  icon,
                  size: 18,
                  color: isActive ? AppColors.primaryBlue : AppColors.textLight,
                ),
                const SizedBox(width: 4),
                Text(
                  label,
                  style: GoogleFonts.poppins(
                    fontSize: 12,
                    fontWeight: isActive ? FontWeight.w600 : FontWeight.normal,
                    color: isActive
                        ? AppColors.primaryBlue
                        : AppColors.textLight,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 4),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
              decoration: BoxDecoration(
                color: isActive
                    ? AppColors.primaryBlue.withOpacity(0.1)
                    : AppColors.backgroundGray,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Text(
                count.toString(),
                style: GoogleFonts.poppins(
                  fontSize: 11,
                  fontWeight: FontWeight.w600,
                  color: isActive ? AppColors.primaryBlue : AppColors.textLight,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSubTabButton(
    String tab,
    String label,
    int count, {
    IconData? icon,
  }) {
    final isActive = _mySitesSubTab == tab;
    // Default icons for sub-tabs if not provided
    final tabIcon = icon ?? _getSubTabIcon(tab);
    return InkWell(
      onTap: () => setState(() => _mySitesSubTab = tab),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 4),
        decoration: BoxDecoration(
          color: isActive
              ? AppColors.primaryBlue.withOpacity(0.1)
              : Colors.transparent,
          border: Border(
            bottom: BorderSide(
              color: isActive ? AppColors.primaryBlue : Colors.transparent,
              width: 2,
            ),
          ),
        ),
        child: Column(
          children: [
            Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(
                  tabIcon,
                  size: 14,
                  color: isActive ? AppColors.primaryBlue : AppColors.textLight,
                ),
                const SizedBox(width: 4),
                Text(
                  label,
                  style: GoogleFonts.poppins(
                    fontSize: 13,
                    fontWeight: isActive ? FontWeight.w600 : FontWeight.normal,
                    color: isActive
                        ? AppColors.primaryBlue
                        : AppColors.textLight,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 2),
            Text(
              count.toString(),
              style: GoogleFonts.poppins(
                fontSize: 11,
                color: isActive ? AppColors.primaryBlue : AppColors.textLight,
              ),
            ),
          ],
        ),
      ),
    );
  }

  IconData _getSubTabIcon(String tab) {
    switch (tab) {
      case 'pending':
        return Icons.pending_actions;
      case 'drafts':
        return Icons.edit_note;
      case 'outbox':
        return Icons.outbox;
      case 'sent':
        return Icons.check_circle_outline;
      default:
        return Icons.folder;
    }
  }

  Widget _buildDataCollectorContent() {
    switch (_enumeratorSubTab) {
      case 'claimable':
        return _buildClaimableSites();
      case 'assigned':
        return _buildSmartAssignedSites();
      case 'my-sites':
        return _buildMySitesContent();
      default:
        return const SizedBox();
    }
  }

  Widget _buildClaimableSites() {
    // Claimable tab requires internet - show offline message
    if (_isOffline) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.wifi_off, size: 64, color: AppColors.primaryOrange),
              const SizedBox(height: 16),
              Text(
                'Internet Required',
                style: GoogleFonts.poppins(
                  fontSize: 18,
                  fontWeight: FontWeight.w600,
                  color: AppColors.textDark,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                'Claiming sites requires an internet connection. Please connect to the internet and try again.',
                style: GoogleFonts.poppins(
                  fontSize: 14,
                  color: AppColors.textLight,
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 24),
              ElevatedButton.icon(
                onPressed: () async {
                  final result = await Connectivity().checkConnectivity();
                  final isOffline = result.contains(ConnectivityResult.none);
                  if (mounted) {
                    setState(() => _isOffline = isOffline);
                    if (!isOffline) {
                      _initializeMMP();
                    }
                  }
                },
                icon: const Icon(Icons.refresh, color: Colors.white),
                label: Text(
                  'Retry',
                  style: GoogleFonts.poppins(color: Colors.white),
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.primaryBlue,
                  padding: const EdgeInsets.symmetric(
                    horizontal: 24,
                    vertical: 12,
                  ),
                ),
              ),
            ],
          ),
        ),
      );
    }

    final filtered = _getFilteredSites(_availableSites);

    if (filtered.isEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.location_off, size: 64, color: AppColors.textLight),
              const SizedBox(height: 16),
              Text(
                'No sites available',
                style: GoogleFonts.poppins(
                  fontSize: 18,
                  fontWeight: FontWeight.w600,
                  color: AppColors.textDark,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                'No sites available in your area yet.',
                style: GoogleFonts.poppins(
                  fontSize: 14,
                  color: AppColors.textLight,
                ),
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
      );
    }

    // Group by state-locality
    final grouped = <String, List<Map<String, dynamic>>>{};
    for (final site in filtered) {
      final state = site['state'] as String? ?? 'Unknown State';
      final locality = site['locality'] as String? ?? 'Unknown Locality';
      final key = '$state - $locality';
      grouped.putIfAbsent(key, () => []).add(site);
    }

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        // Info card
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.blue.shade50,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: Colors.blue.shade200),
          ),
          child: Row(
            children: [
              Icon(Icons.info_outline, color: Colors.blue.shade700),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'First-Come, First-Served',
                      style: GoogleFonts.poppins(
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                        color: Colors.blue.shade900,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'Tap "Claim Site" to assign a site to yourself. Be quick - other enumerators can see these sites too!',
                      style: GoogleFonts.poppins(
                        fontSize: 12,
                        color: Colors.blue.shade800,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),

        // Grouped sites
        ...grouped.entries.map(
          (entry) => _buildSiteGroup(entry.key, entry.value),
        ),
      ],
    );
  }

  Widget _buildSiteGroup(String title, List<Map<String, dynamic>> sites) {
    return ExpansionTile(
      title: Text(
        title,
        style: GoogleFonts.poppins(fontSize: 16, fontWeight: FontWeight.w600),
      ),
      subtitle: Text(
        '${sites.length} site${sites.length != 1 ? 's' : ''}',
        style: GoogleFonts.poppins(fontSize: 12, color: AppColors.textLight),
      ),
      children: sites
          .map((site) => _buildSiteCard(site, showClaimButton: true))
          .toList(),
    );
  }

  Widget _buildSmartAssignedSites() {
    final filtered = _getFilteredSites(_smartAssignedSites);

    if (filtered.isEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                Icons.assignment_outlined,
                size: 64,
                color: AppColors.textLight,
              ),
              const SizedBox(height: 16),
              Text(
                'No assigned sites',
                style: GoogleFonts.poppins(
                  fontSize: 18,
                  fontWeight: FontWeight.w600,
                  color: AppColors.textDark,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                'No sites assigned to you yet.',
                style: GoogleFonts.poppins(
                  fontSize: 14,
                  color: AppColors.textLight,
                ),
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
      );
    }

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.orange.shade50,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: Colors.orange.shade200),
          ),
          child: Row(
            children: [
              Icon(Icons.warning_amber, color: Colors.orange.shade700),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  'Sites under this category are mandatory to be visited. If you have any issues, please contact your immediate supervisors.',
                  style: GoogleFonts.poppins(
                    fontSize: 12,
                    color: Colors.orange.shade900,
                  ),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),
        ...filtered.map(
          (site) => _buildSiteCard(site, showAcknowledgeButton: true),
        ),
      ],
    );
  }

  Widget _buildMySitesContent() {
    List<Map<String, dynamic>> sitesToShow = [];

    switch (_mySitesSubTab) {
      case 'pending':
        sitesToShow = _mySites.where((site) {
          final status = (site['status'] as String? ?? '').toLowerCase();
          return status == 'accepted' ||
              status == 'assigned' ||
              status == 'dispatched' ||
              status == 'pending';
        }).toList();
        break;
      case 'drafts':
        sitesToShow = _mySites.where((site) {
          final status = (site['status'] as String? ?? '').toLowerCase();
          final isInProgress =
              status == 'in progress' ||
              status == 'in_progress' ||
              status == 'ongoing';

          // Only show in drafts if it's in progress AND doesn't have a synced report
          return isInProgress && !_hasSyncedReport(site);
        }).toList();
        break;
      case 'outbox':
        // Completed but not yet synced: server-completed-no-report + offline-only completions
        sitesToShow = _mySites.where((site) {
          final status = (site['status'] as String? ?? '').toLowerCase();
          final isCompleted = status == 'completed' || status == 'complete';
          return isCompleted && !_hasSyncedReport(site);
        }).toList();
        break;
      case 'sent':
        // Only fully synced: has report on server (wallet reflects money)
        sitesToShow = _mySites.where((site) => _hasSyncedReport(site)).toList();
        break;
    }

    final filtered = _getFilteredSites(sitesToShow);

    if (filtered.isEmpty) {
      String message = 'No sites found';
      switch (_mySitesSubTab) {
        case 'pending':
          message = 'No pending visits found.';
          break;
        case 'drafts':
          message =
              'No in-progress or ongoing site visits found. Start a visit to see it here.';
          break;
        case 'outbox':
          message =
              'No completed visits waiting to sync. All visits have been submitted.';
          break;
        case 'sent':
          message = 'No completed sites found.';
          break;
      }

      return Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Text(
            message,
            style: GoogleFonts.poppins(
              fontSize: 14,
              color: AppColors.textLight,
            ),
            textAlign: TextAlign.center,
          ),
        ),
      );
    }

    return ListView(
      padding: const EdgeInsets.all(16),
      children: filtered
          .map((site) => _buildSiteCard(site, showVisitActions: true))
          .toList(),
    );
  }

  Widget _buildSiteCard(
    Map<String, dynamic> site, {
    bool showClaimButton = false,
    bool showAcknowledgeButton = false,
    bool showVisitActions = false,
  }) {
    final siteName = site['site_name'] ?? site['siteName'] ?? 'Unknown Site';
    final siteCode = site['site_code'] ?? site['siteCode'] ?? '';
    final state = site['state'] ?? '';
    final locality = site['locality'] ?? '';
    final status = site['status'] ?? 'Pending';
    final storedEnumeratorFee =
        (site['enumerator_fee'] as num?)?.toDouble() ?? 0.0;
    final transportFee = (site['transport_fee'] as num?)?.toDouble() ?? 0.0;
    // For claimable sites (Dispatched), use user's classification-based fee if site has no enumerator_fee
    final isClaimableSite = status.toLowerCase() == 'dispatched';
    final enumeratorFee = (storedEnumeratorFee > 0)
        ? storedEnumeratorFee
        : (isClaimableSite ? _userEnumeratorFee : 0.0);
    // Calculate total as enumerator_fee + transport_fee
    final cost = enumeratorFee + transportFee;

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.backgroundGray),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 5,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      siteName.toString(),
                      style: GoogleFonts.poppins(
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                        color: AppColors.textDark,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      '$locality, $state',
                      style: GoogleFonts.poppins(
                        fontSize: 12,
                        color: AppColors.textLight,
                      ),
                    ),
                    if (siteCode.isNotEmpty) ...[
                      const SizedBox(height: 2),
                      Text(
                        'Code: $siteCode',
                        style: GoogleFonts.poppins(
                          fontSize: 11,
                          color: AppColors.textLight,
                        ),
                      ),
                    ],
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: _getStatusColor(status).withOpacity(0.1),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  status.toUpperCase(),
                  style: GoogleFonts.poppins(
                    fontSize: 10,
                    fontWeight: FontWeight.w600,
                    color: _getStatusColor(status),
                  ),
                ),
              ),
            ],
          ),

          // Show only Total (no Transport/Enumerator breakdown)
          // Hide total for claimable sites - it will be shown in the claim confirmation dialog
          if (cost > 0 && !showClaimButton) ...[
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
              decoration: BoxDecoration(
                color: AppColors.backgroundGray,
                borderRadius: BorderRadius.circular(8),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Total',
                    style: GoogleFonts.poppins(
                      fontSize: 13,
                      fontWeight: FontWeight.w600,
                      color: AppColors.textDark,
                    ),
                  ),
                  Text(
                    '${cost.toStringAsFixed(0)} SDG',
                    style: GoogleFonts.poppins(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: AppColors.primaryBlue,
                    ),
                  ),
                ],
              ),
            ),
          ],

          const SizedBox(height: 12),
          _buildActionButtons(
            site,
            status: status,
            showClaimButton: showClaimButton,
            showAcknowledgeButton: showAcknowledgeButton,
            showVisitActions: showVisitActions,
          ),
          // Contact buttons (Call, SMS, WhatsApp) if contact info is available
          _buildContactButtons(site),
        ],
      ),
    );
  }

  Widget _buildCoordinatorView() {
    final filtered = _getFilteredSites(_coordinatorSites);

    return Column(
      children: [
        // Header
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [Color(0xFF2563EB), Color(0xFF1E40AF)],
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.blue.withOpacity(0.3),
                blurRadius: 10,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: const Icon(
                      Icons.verified_user,
                      color: Colors.white,
                      size: 24,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Verified Sites',
                          style: GoogleFonts.poppins(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                          ),
                        ),
                        Text(
                          'Sites forwarded to you for verification',
                          style: GoogleFonts.poppins(
                            fontSize: 12,
                            color: Colors.white.withOpacity(0.9),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),

        // Search
        Padding(
          padding: const EdgeInsets.all(16),
          child: TextField(
            controller: _searchController,
            onChanged: (value) {
              setState(() => _searchQuery = value);
            },
            decoration: InputDecoration(
              hintText: 'Search sites...',
              prefixIcon: const Icon(Icons.search),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              filled: true,
              fillColor: Colors.white,
            ),
          ),
        ),

        // Sites list
        Expanded(
          child: filtered.isEmpty
              ? Center(
                  child: Padding(
                    padding: const EdgeInsets.all(32),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          Icons.assignment_outlined,
                          size: 64,
                          color: AppColors.textLight,
                        ),
                        const SizedBox(height: 16),
                        Text(
                          'No sites found',
                          style: GoogleFonts.poppins(
                            fontSize: 18,
                            fontWeight: FontWeight.w600,
                            color: AppColors.textDark,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          'No sites have been forwarded to you yet.',
                          style: GoogleFonts.poppins(
                            fontSize: 14,
                            color: AppColors.textLight,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ],
                    ),
                  ),
                )
              : ListView(
                  padding: const EdgeInsets.all(16),
                  children: filtered
                      .map((site) => _buildCoordinatorSiteCard(site))
                      .toList(),
                ),
        ),
      ],
    );
  }

  Widget _buildCoordinatorSiteCard(Map<String, dynamic> site) {
    final siteName = site['site_name'] ?? site['siteName'] ?? 'Unknown Site';
    final siteCode = site['site_code'] ?? site['siteCode'] ?? '';
    final state = site['state'] ?? '';
    final locality = site['locality'] ?? '';
    final status = site['status'] ?? 'Pending';
    final isCompleted =
        status.toString().toLowerCase() == 'completed' ||
        status.toString().toLowerCase() == 'complete';

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.backgroundGray),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      siteName.toString(),
                      style: GoogleFonts.poppins(
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      '$locality, $state',
                      style: GoogleFonts.poppins(
                        fontSize: 12,
                        color: AppColors.textLight,
                      ),
                    ),
                    if (siteCode.isNotEmpty) ...[
                      const SizedBox(height: 2),
                      Text(
                        'Code: $siteCode',
                        style: GoogleFonts.poppins(
                          fontSize: 11,
                          color: AppColors.textLight,
                        ),
                      ),
                    ],
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: _getStatusColor(status).withOpacity(0.1),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  status.toUpperCase(),
                  style: GoogleFonts.poppins(
                    fontSize: 10,
                    fontWeight: FontWeight.w600,
                    color: _getStatusColor(status),
                  ),
                ),
              ),
            ],
          ),
          if (isCompleted && (_isAdminOrSuperUser || _userRole == 'fom')) ...[
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: () => _viewVisitReport(site),
                icon: const Icon(Icons.visibility, size: 18),
                label: const Text('View Visit Report'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blue,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 10),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }

  void _viewVisitReport(Map<String, dynamic> site) {
    final siteVisit = SiteVisit(
      id: site['id']?.toString() ?? '',
      siteName:
          site['site_name']?.toString() ??
          site['siteName']?.toString() ??
          'Unknown',
      siteCode:
          site['site_code']?.toString() ?? site['siteCode']?.toString() ?? '',
      state: site['state']?.toString() ?? '',
      locality: site['locality']?.toString() ?? '',
      status: site['status']?.toString() ?? '',
      activity:
          site['activity']?.toString() ??
          site['main_activity']?.toString() ??
          '',
      priority: site['priority']?.toString() ?? 'medium',
      notes: site['notes']?.toString() ?? '',
      mainActivity:
          site['main_activity']?.toString() ??
          site['activity']?.toString() ??
          '',
      assignedTo:
          site['accepted_by']?.toString() ??
          site['assigned_to']?.toString() ??
          '',
      createdAt: site['created_at'] != null
          ? DateTime.tryParse(site['created_at'].toString()) ?? DateTime.now()
          : DateTime.now(),
      transportFee: (site['transport_fee'] as num?)?.toDouble() ?? 0,
      enumeratorFee: (site['enumerator_fee'] as num?)?.toDouble() ?? 0,
      dueDate: site['due_date'] != null
          ? DateTime.tryParse(site['due_date'].toString())
          : null,
    );

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => VisitReportDetailScreen(visit: siteVisit),
      ),
    );
  }

  Color _getStatusColor(String status) {
    final s = status.toLowerCase();
    if (s == 'completed' || s == 'complete') return Colors.green;
    if (s == 'in progress' || s == 'in_progress' || s == 'ongoing') {
      return Colors.blue;
    }
    if (s == 'pending' || s == 'assigned' || s == 'dispatched') {
      return Colors.orange;
    }
    if (s == 'verified') return Colors.purple;
    if (s == 'rejected') return Colors.red;
    return AppColors.textLight;
  }

  int _getPendingCount() {
    return _mySites.where((site) {
      final status = (site['status'] as String? ?? '').toLowerCase();
      return status == 'accepted' ||
          status == 'assigned' ||
          status == 'dispatched' ||
          status == 'pending';
    }).length;
  }

  int _getDraftsCount() {
    return _mySites.where((site) {
      final status = (site['status'] as String? ?? '').toLowerCase();
      return status == 'in progress' ||
          status == 'in_progress' ||
          status == 'ongoing';
    }).length;
  }

  int _getOutboxCount() {
    return _mySites.where((site) {
      final status = (site['status'] as String? ?? '').toLowerCase();
      final isCompleted = status == 'completed' || status == 'complete';
      return isCompleted && !_hasSyncedReport(site);
    }).length;
  }

  int _getSentCount() {
    return _mySites.where((site) => _hasSyncedReport(site)).length;
  }
}

// Cost Acknowledgment Dialog
class _CostAcknowledgmentDialog extends StatefulWidget {
  final Map<String, dynamic> site;

  const _CostAcknowledgmentDialog({required this.site});

  @override
  State<_CostAcknowledgmentDialog> createState() =>
      _CostAcknowledgmentDialogState();
}

class _CostAcknowledgmentDialogState extends State<_CostAcknowledgmentDialog> {
  bool _acknowledged = false;

  @override
  Widget build(BuildContext context) {
    final site = widget.site;
    final enumeratorFee = site['enumerator_fee'] ?? 0;
    final transportFee = site['transport_fee'] ?? 0;
    // Always calculate total as transport + enumerator fee (not just site['cost'])
    final totalCost =
        (transportFee is num ? transportFee : 0) +
        (enumeratorFee is num ? enumeratorFee : 0);

    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Cost Acknowledgment',
              style: GoogleFonts.poppins(
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 16),
            Text(
              'Site: ${site['site_name'] ?? site['siteName'] ?? 'Unknown'}',
              style: GoogleFonts.poppins(
                fontSize: 14,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: AppColors.backgroundGray,
                borderRadius: BorderRadius.circular(8),
              ),
              child: Column(
                children: [
                  _buildCostRow('Total Cost', totalCost, isTotal: true),
                ],
              ),
            ),
            const SizedBox(height: 16),
            CheckboxListTile(
              value: _acknowledged,
              onChanged: (value) =>
                  setState(() => _acknowledged = value ?? false),
              title: Text(
                'I acknowledge receipt of the cost details',
                style: GoogleFonts.poppins(fontSize: 12),
              ),
            ),
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                TextButton(
                  onPressed: () => Navigator.of(context).pop(false),
                  child: const Text('Cancel'),
                ),
                const SizedBox(width: 8),
                ElevatedButton(
                  onPressed: _acknowledged
                      ? () => Navigator.of(context).pop(true)
                      : null,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.green,
                    foregroundColor: Colors.white,
                  ),
                  child: const Text('Acknowledge'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCostRow(String label, num amount, {bool isTotal = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: GoogleFonts.poppins(
              fontSize: isTotal ? 16 : 14,
              fontWeight: isTotal ? FontWeight.bold : FontWeight.normal,
            ),
          ),
          Text(
            '${amount.toStringAsFixed(0)} SDG',
            style: GoogleFonts.poppins(
              fontSize: isTotal ? 18 : 14,
              fontWeight: FontWeight.bold,
              color: isTotal ? AppColors.primaryBlue : AppColors.textDark,
            ),
          ),
        ],
      ),
    );
  }
}
