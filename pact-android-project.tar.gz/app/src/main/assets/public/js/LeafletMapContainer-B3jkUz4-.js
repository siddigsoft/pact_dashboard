import{j as s,r as g}from"./vendor-BQkvefv6.js";import{C as u,M as b,T as f,a as w,P as v,L as d,u as y}from"./maps-T9Puaeb-.js";import{C as j,b as k,A as N,c as $,d as C,B as x}from"./index-CJxOyMbo.js";import{h as A}from"./sudanStates-BPbwQL0N.js";import{G as M,M as z,t as B,ac as E}from"./icons-B8P4BJuz.js";const I=({hub:t,color:i})=>{var r,n;return!((r=t.coordinates)!=null&&r.latitude)||!((n=t.coordinates)!=null&&n.longitude)?null:s.jsx(u,{center:[t.coordinates.latitude,t.coordinates.longitude],radius:5e4,pathOptions:{fillColor:i,fillOpacity:.2,color:i,weight:2}})};delete d.Icon.Default.prototype._getIconUrl;d.Icon.Default.mergeOptions({iconRetinaUrl:"https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon-2x.png",iconUrl:"https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon.png",shadowUrl:"https://unpkg.com/leaflet@1.7.1/dist/images/marker-shadow.png"});const c=t=>{const i={"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;","/":"&#x2F;","`":"&#x60;","=":"&#x3D;"};return t.replace(/[&<>"'`=/]/g,r=>i[r]||r)},F={"kassala-hub":"#9b87f5","kosti-hub":"#F97316","forchana-hub":"#D946EF","dongola-hub":"#0EA5E9","country-office":"#8B5CF6"},L=({locations:t,defaultCenter:i,defaultZoom:r})=>{const n=y();return g.useEffect(()=>{if(!t||t.length===0){try{n.setView(i,r)}catch{}return}const o=t.filter(a=>a.latitude&&a.longitude).map(a=>[a.latitude,a.longitude]);if(o.length>0)try{const a=d.latLngBounds(o);n.fitBounds(a,{padding:[50,50]})}catch{}},[n,t,i,r]),null},U=(t,i,r,n)=>{const o=t==="user"?i==="online"?"#10b981":i==="busy"?"#f59e0b":"#6b7280":i==="completed"?"#10b981":i==="inProgress"?"#6366f1":i==="assigned"?"#f59e0b":"#ef4444";if(t==="site")return d.divIcon({className:"custom-div-icon",html:`
        <div style="
          background-color: ${o};
          width: 20px;
          height: 20px;
          border-radius: 4px;
          border: 2px solid white;
          box-shadow: 0 2px 6px rgba(0,0,0,0.3);
          display: flex;
          align-items: center;
          justify-content: center;
        ">
          <svg width="12" height="12" viewBox="0 0 24 24" fill="white" xmlns="http://www.w3.org/2000/svg">
            <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z"/>
          </svg>
        </div>
      `,iconSize:[20,20],iconAnchor:[10,10]});const a=n?c(n):"",p=r?c(r):"",l=n?c(n.split(" ").map(m=>m[0]).join("").substring(0,2).toUpperCase()):"?",e=i==="online"?"#10b981":i==="busy"?"#f59e0b":"#6b7280",h=i==="online"?"animation: pulse 2s infinite;":"";return r?d.divIcon({className:"custom-user-marker",html:`
        <style>
          @keyframes pulse {
            0%, 100% { box-shadow: 0 0 0 0 ${e}80; }
            50% { box-shadow: 0 0 0 6px ${e}00; }
          }
        </style>
        <div style="
          position: relative;
          width: 44px;
          height: 44px;
          ${h}
        ">
          <div style="
            position: absolute;
            top: 0;
            left: 0;
            width: 44px;
            height: 44px;
            border-radius: 50%;
            border: 3px solid ${e};
            box-shadow: 0 2px 8px rgba(0,0,0,0.3);
            overflow: hidden;
            background: white;
          ">
            <img 
              src="${p}" 
              alt="${a||"User"}"
              style="width: 100%; height: 100%; object-fit: cover;"
              onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';"
            />
            <div style="
              display: none;
              width: 100%;
              height: 100%;
              background: linear-gradient(135deg, ${e}90, ${e});
              color: white;
              font-size: 14px;
              font-weight: bold;
              align-items: center;
              justify-content: center;
            ">${l}</div>
          </div>
          <div style="
            position: absolute;
            bottom: -2px;
            right: -2px;
            width: 14px;
            height: 14px;
            border-radius: 50%;
            background: ${e};
            border: 2px solid white;
            box-shadow: 0 1px 3px rgba(0,0,0,0.3);
          "></div>
        </div>
      `,iconSize:[44,44],iconAnchor:[22,22],popupAnchor:[0,-22]}):d.divIcon({className:"custom-user-marker",html:`
      <style>
        @keyframes pulse {
          0%, 100% { box-shadow: 0 0 0 0 ${e}80; }
          50% { box-shadow: 0 0 0 6px ${e}00; }
        }
      </style>
      <div style="
        position: relative;
        width: 44px;
        height: 44px;
        ${h}
      ">
        <div style="
          position: absolute;
          top: 0;
          left: 0;
          width: 44px;
          height: 44px;
          border-radius: 50%;
          border: 3px solid ${e};
          box-shadow: 0 2px 8px rgba(0,0,0,0.3);
          overflow: hidden;
          background: linear-gradient(135deg, ${e}90, ${e});
          display: flex;
          align-items: center;
          justify-content: center;
        ">
          <span style="
            color: white;
            font-size: 14px;
            font-weight: bold;
            text-shadow: 0 1px 2px rgba(0,0,0,0.3);
          ">${l}</span>
        </div>
        <div style="
          position: absolute;
          bottom: -2px;
          right: -2px;
          width: 14px;
          height: 14px;
          border-radius: 50%;
          background: ${e};
          border: 2px solid white;
          box-shadow: 0 1px 3px rgba(0,0,0,0.3);
        "></div>
      </div>
    `,iconSize:[44,44],iconAnchor:[22,22],popupAnchor:[0,-22]})},R=({locations:t=[],height:i="500px",onLocationClick:r,mapType:n="standard",defaultCenter:o=[20,0],defaultZoom:a=3,showHubs:p=!1})=>{const l=e=>e?new Date(e).toLocaleString():"Never";return s.jsx("div",{style:{height:"100%",width:"100%"},className:"rounded-lg",children:s.jsxs(b,{center:o,zoom:a,style:{height:"100%",width:"100%"},className:"rounded-lg",minZoom:2,maxBounds:[[-90,-180],[90,180]],children:[s.jsx(f,{url:"https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",attribution:'© <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'}),p&&A.map(e=>s.jsx(I,{hub:e,color:F[e.id]||"#6b7280"},e.id)),t&&t.map(e=>s.jsx(w,{position:[e.latitude,e.longitude],icon:U(e.type,e.status,e.avatar,e.name),eventHandlers:{click:()=>r&&r(e.id)},children:s.jsx(v,{children:s.jsx(j,{className:"w-[300px] border-none shadow-none",children:s.jsxs(k,{className:"p-3",children:[s.jsxs("div",{className:"flex items-start gap-3",children:[s.jsxs(N,{className:"h-12 w-12",children:[s.jsx($,{src:e.avatar}),s.jsx(C,{children:e.name.substring(0,2).toUpperCase()})]}),s.jsxs("div",{className:"flex-1",children:[s.jsx("h3",{className:"font-semibold text-base",children:e.name}),s.jsxs("div",{className:"flex items-center gap-1 mt-1",children:[s.jsx(x,{variant:e.status==="online"?"default":"secondary",children:e.status}),e.workload!==void 0&&s.jsxs(x,{variant:"outline",children:[e.workload," tasks"]})]})]})]}),s.jsxs("div",{className:"mt-3 space-y-2 text-sm text-muted-foreground",children:[e.type==="user"&&e.phone&&s.jsxs("div",{className:"flex items-center gap-2",children:[s.jsx(M,{className:"h-4 w-4"}),s.jsx("span",{children:e.phone})]}),s.jsxs("div",{className:"flex items-center gap-2",children:[s.jsx(z,{className:"h-4 w-4"}),s.jsxs("span",{children:["[",e.latitude.toFixed(4),", ",e.longitude.toFixed(4),"]"]})]}),e.type==="user"&&s.jsxs("div",{className:"flex items-center gap-2",children:[s.jsx(B,{className:"h-4 w-4"}),s.jsxs("span",{children:["Last active: ",l(e.lastActive)]})]}),e.type==="user"&&e.workload!==void 0&&s.jsxs("div",{className:"flex items-center gap-2",children:[s.jsx(E,{className:"h-4 w-4"}),s.jsxs("span",{children:["Workload: ",e.workload," tasks"]})]})]})]})})})},e.id)),s.jsx(L,{locations:t,defaultCenter:o,defaultZoom:a})]})})};export{R as L};
